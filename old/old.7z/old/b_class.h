/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_CLASS
#define _EMBER_CLASS

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CClass
{
public:
    CClass();
    virtual ~CClass();
    char    name[64];
    unsigned long  sid;
	CClass *pNext;
   
};

#endif // _EMBER_CLASS
