/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_S_CLIENT_H
#define _EMBER_S_CLIENT_H
/*

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "global.h"
#include "s_server.h"
#include "s_socket.h"
#include "b_toon.h"

class C_FM_CLIENT
{
public:
    C_FM_CLIENT();
    ~C_FM_CLIENT();

	C_Toon		*toon;	// Current toon

	char		name[1024];
	
	void		VortexInsert(void);
	int			sid;
	char		access;
    void        Disconnect(void);
    void        SetState(eConnectionState eNewState);       // state of the connection  
    void        SetSocket(CSocket *pNewSocket);             // sets the lowlevel netinterface
    CSocket     *pSocket;                                   // lowlevel network interface
    CSocket     *pGetSocket(void);                          // gets the lowlevel netinterface
    bool        bLoggedin;                                  // is the player logged in
    bool        bSystemBusy;                                // set if internal stuff to do
    int         iGetMessage(void);                          // tries to receive a message
    char        *get_remote_ip(void);
    C_FM_CLIENT *pNext;
    C_FM_CLIENT *pPrevious;

	void		Save(char *tname);
	void		Load(char *tname);

	void		LoadToon(int iSlot);
	
    void        do_net(void);

	void		LoginReply(int iLoginType,char * szAnswerMessage);

    CPacket     *SendPacket;

    // commands to push net messages the actual client follow :
    
    bool        AddGUIStump     (char *name,int x,int y,int x2,int y2,int props,char *media);
    bool        ModGUIStump     (char *name,int x,int y,int x2,int y2,int props,char *media);
    bool        DelGUIStump     (char *name);
    bool        GUIStumpCaption (char *name,char *caption);
    bool        AddGUIControl   (char *stump,char *name,int type,int props,int x,int y,int x2,int y2,char *media,char *value);
    bool        DelGUIControl   (char *stump,char *name);
    int         ModGUIControl   (char *stump,char *name);
    bool        GUIControlValue (char *stump,char *name,char *value);
    bool        ClearGUI        (void);
	    
//    bool        SetDrawMap      (int dm);
//    bool        SetLimboState   (int lm);
//    bool        SetGameMode     (int gm);
//    bool        SetDayLight     (float r,float g,float b);
    
//    bool        SetCam          (int x,int y,int z, int ax,int ay,int az,int ox,int oy,int oz);
//    bool        MoveCamTo       (int x,int y,int z);
//    bool        ZoomCamTo       (int zoom);
//    bool        ScrollCamTo     (int x,int y,int z);
    
//    bool        VisRemove       (int ntt);
//    bool        VisMove         (int ntt,int x,int y,int z,char* media,int media_type,int head,int dir);

//    bool        SetMapTile      (int x,int y,int z,int bank,int tile);
//    bool        SetMapObject    (int x,int y,int z,int l,int bank,int obj);
//    bool        SetMapProp      (int x,int y,int z,int prop);
//    bool        SetMapVWidth    (int x,int y,int z,int v,int w);
//    bool        SetMapVHeight   (int x,int y,int z,int v,int h);
//    bool        SetMapVColor    (int x,int y,int z,int v,char r,char g,char b);
    
    eConnectionState eGetState(void);
    void		fm_client_init(void);
};

  */
#endif // _EMBER_S_CLIENT_H
