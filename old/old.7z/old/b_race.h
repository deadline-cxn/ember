/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_RACE
#define _EMBER_RACE


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRace
{
public:
    CRace();
    virtual ~CRace();
    char    name[64];
    unsigned long  sid;
	CRace *pNext;

    
};

#endif // _EMBER_RACE
