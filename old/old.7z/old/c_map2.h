/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_MAP_CLIENT
#define _EMBER_MAP_CLIENT

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "b_map.h"

#ifndef _FMSERVER_
#ifndef _FMMS_
#ifndef _FMMS_WEB_


class C_FM_VIS;

class CC_M_VIS_DATA
{
public:
    CC_M_VIS_DATA()  { next=0; }; 
    ~CC_M_VIS_DATA() { };
    C_FM_VIS *pVIS;
    CC_M_VIS_DATA *next;
};
//typedef
struct iVISData { CC_M_VIS_DATA *pVISData; CC_M_VIS_DATA *pFirstVISData; };

#endif
#endif
#endif

class CC_Map : public CEmMap
{
public:
	CC_Map();
	virtual ~CC_Map();

	//////////////////////////////////////////////////////
	// Methods

	bool	bInitialize(int x, int y, u_char bank, u_char tile);

	void	CleanUp(void);	

	// Map Movement Functions:

	bool    Scroll(int x, int y, int scrollspeed);
	int 	ScrollIso(u_char SCRDIR, int speed);

	int		GetScrollX(void);
	int		GetScrollY(void);
	void	SetScrollX(int sx);
	void	SetScrollY(int sy);

	bool    IsValidTile(u_char bank, u_char tile);
	void	SetTileDimensions(int iTWidth, int iTHeight);
	void	SetMapDraw(int sx, int sy, int tx, int ty);
	void	SetColorKey(long color, bool yesno);

	short	GetTilesToDrawX(void);
	short	GetTilesToDrawY(void);

	int		GetScreenX(void);
	int		GetScreenY(void);

	int		GetTileWidth(void);
	int		GetTileHeight(void);
    
	//////////////////////////////////////////////////////
	//	Class variables

	short		    ScreenX;
	short		    ScreenY;
	short		    ScrollX;
	short		    ScrollY;
	unsigned long   ColorKey;
	bool		    ColorKeyActive;

	short		    TileWidth;
	short		    TileHeight;
	short		    TilesToDrawX;
	short		    TilesToDrawY;

    
#ifndef _FMSERVER_
#ifndef _FMMS_
#ifndef _FMMS_WEB_
    iVISData        *VISData;
#endif
#endif
#endif

    int     iKey;
    CC_Map  *pNext;
    CC_Map  *pPrevious;
    	
};


#endif // _EMBER_MAP_CLIENT
