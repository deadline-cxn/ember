/***************************************************************
 **      EMBER                                                **
 ***************************************************************

#ifndef _EMBER_CONSOLE
#define _EMBER_CONSOLE

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef __cplusplus
extern "C"
{
#endif
    void ffProcessConsoleCommand(char *szCommand, bool bEcho);
#ifdef __cplusplus
}
#endif

#endif


*/



