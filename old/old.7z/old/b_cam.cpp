/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#include "b_cam.h"

//////////////////////////////////////////////////////
C_FM_CAMERA::C_FM_CAMERA() { fm_camera_init(); }
//////////////////////////////////////////////////////
void C_FM_CAMERA::fm_camera_init()
{
    fm_vis_init();
	//x=y=z;
	tx=ty=tz=px=py=pz=vx=vy=vz=ux=uy=uz=0;
    //ox=oy=oz=ax=ay=az=zoom=0;
    r=g=b=255;
    set_translate(0,0,0);
    set_position(0,0,0);
    set_view(0,0,0);
    set_up(0,0,0);
    //camstop=1;
    //zoomup=zoomdown=axup=axdown=ayup=aydown=azup=azdown=oxup=oxdown=oyup=oydown=ozup=ozdown=0;
}
//////////////////////////////////////////////////////
C_FM_CAMERA::~C_FM_CAMERA() { }
//////////////////////////////////////////////////////
/*
void C_FM_CAMERA::update(void)
{
    if(zoomup)      zoom+=20;
    if(zoomdown)    zoom-=20;
    if(axup)        ax+=2;
    if(axdown)      ax-=2;
    if(ayup)        ay+=2;
    if(aydown)      ay-=2;
    if(azup)        az+=2;
    if(azdown)      az-=2;
    if(oxup)        ox+=2;
    if(oxdown)      ox-=2;
    if(oyup)        oy+=2;
    if(oydown)      oy-=2;
    if(ozup)        oz+=2;
    if(ozdown)      oz-=2;

    if(ax<0)  { camstop=1; ax=0;  }
    if(ax>40) { camstop=1; ax=40; }

    if(az>360)  { az=360-az; }
    if(az<-360) { az=az+360; }

    if(zoom>230)  { camstop=1; zoom=230;  }
    if(zoom<-250) { camstop=1; zoom=-250; }


    if(camstop)
    {
        zoomup=0;
        zoomdown=0;
        axup=0;
        axdown=0;
        ayup=0;
        aydown=0;
        azup=0;
        azdown=0;
        oxup=0;
        oxdown=0;
        oyup=0;
        oydown=0;
        ozup=0;
        ozdown=0;
        camstop=0;
    }
}
*/
//////////////////////////////////////////////////////
void C_FM_CAMERA::set_translate(float nx,float ny,float nz)	{ tx=nx; ty=ny; tz=nz; }
void C_FM_CAMERA::set_position(float nx,float ny,float nz)	{ px=nx; py=ny; pz=nz; }
void C_FM_CAMERA::set_view(float nx,float ny,float nz)		{ vx=nx; vy=ny; vz=nz; }
void C_FM_CAMERA::set_up(float nx,float ny,float nz)		{ ux=nx; uy=ny; uz=nz; }
//////////////////////////////////////////////////////
//void C_FM_CAMERA::offset(float nx,float ny,float nz) { ox=nx; oy=ny; oz=nz; }
//////////////////////////////////////////////////////
//void C_FM_CAMERA::set_angle(float nx,float ny,float nz) { ax=nx; ay=ny; az=nz; }
//////////////////////////////////////////////////////
//void C_FM_CAMERA::set_filter(unsigned char nr, unsigned char ng, unsigned char nb) { r=nr; g=ng; b=nb; }
//////////////////////////////////////////////////////
//void C_FM_CAMERA::set_zoom(float nzoom) { zoom=nzoom; }
//////////////////////////////////////////////////////

