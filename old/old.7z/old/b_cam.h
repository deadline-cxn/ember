/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_BASE_CAMERA
#define _EMBER_BASE_CAMERA

//#include "global.h"
#include "b_vis.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class C_FM_VIS;

class C_FM_CAMERA : public C_FM_VIS
{
public:
    C_FM_CAMERA();
    virtual ~C_FM_CAMERA();

	float tx; // opengl translate
	float ty;
	float tz;

	float   px, py, pz; // position vector
	float   vx, vy, vz; // view vector
	float	 ux, uy, uz; // up vector

    float   rx, ry, rz; // offset

    //bool    oxup,oyup,ozup;
    //bool    oxdown,oydown,ozdown;

    //float   ax, ay, az; // angle to look at
    //bool    axup,ayup,azup;
    //bool    axdown,aydown,azdown;

    //float   zoom;
    //bool    zoomup;
    //bool    zoomdown;

    float	lock_object;

    bool    camstop;

    void    set_translate(float nx,float ny,float nz);
    void    set_position(float nx,float ny,float nz);
	void    set_view(float nx,float ny,float nz);
	void    set_up(float nx,float ny,float nz);

    // void    offset    (float nx,float ny,float nz);
    // void    set_angle (float nx,float ny,float nz);
    // void    set_filter(unsigned char nr,unsigned char ng,unsigned char nb);
    // void    set_zoom  (float nzoom);
    // void    update(void);
    void    fm_camera_init(void);


};

#endif // _EMBER_BASE_CAMERA
