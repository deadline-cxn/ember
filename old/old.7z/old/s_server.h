/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_SERVER_H
#define _EMBER_SERVER_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "global.h"
#include "s_serverinfo.h"
#include "dlstorm.h"
#include "c_net.h"
#include "b_netaddress.h"
#include "s_client.h"
#include "b_toon.h"
#include "b_map.h"

// class CNPC;
// class CPacket;
// class C_FM_CLIENT;
// class CServerSocket;

class CSocket
{
public:
    CSocket(void);
    ~CSocket();

    virtual int     iGetMessage();
	// 0 if no incomming data, 1 unreliable, 2 reliable
    virtual char    *pcGetMessage();
    virtual int     iGetMessageSize();
    virtual         CPacket *pGetMessage();
    virtual bool    bCanSendMessage ();
	// returns true if a reliable message can be send
    virtual void    SendReliableMessage (char *pData, int iSize);
    virtual void    SendReliableMessage (CPacket *pMessage);
    virtual void    SendUnreliableMessage(char *pData,int iSize);
    virtual void    SendUnreliableMessage(CPacket *pMessage);
    virtual void    Disconnect();
    // if a dead connection is returned by a get or send function,
	// this function should be called when it is convenient
    CInetAddress    *pGetAddress(void);
    void            SetAddress(CInetAddress *pAddress);
	// connection information
    void            SendMessageNext(void);
    void            ReSendMessage (void);
    void            FinishCtlPacket(CPacket *pPacket);

    //virtual void    SendBufferedMessage(char *pData,int iSize);
    //virtual void    SendBufferedMessage(CPacket *pMessage);

    int             iExtractBufferedMessage(int iPos=0);

    #pragma pack(1)
    struct jerry
    {
        unsigned int  iLen;
        unsigned int  iSequence;
        char          pData[MAX_DATAGRAM];
    } PacketBuffer,ExtrBackupBuffer;
    #pragma pack()
    int iLastLength;
    int iSocket;
    CInetAddress *pAddr;
    CPacket *pTempPacket;       // temporary packet for pGetMessage
    bool bConnected ;           // exists a validated connection?
    bool bCanSend;              // indicates wether reliable messages can be sent or not
    bool bSendNext;             // can we send next part of the message

	bool bExtractBuffer;        // indicates that a buffered message was received

    //queue<int> BufferedQ;       // sizes of the buffered packets

	int iCurrentBuffer ;        // current size of buffered data
    char *pBackupBuffer;        // queuebuffer for buffered messages
    char *pSendBuffer;          // pointer to sendbuffer
    int   iCurBufSize;          // current size of messagebuffer
    int   iSendBufferLength;    // length of current message
    char *pReceiveBuffer;       // pointer to receivebuffer
    int iCurReceiveSize;        // current size of receivebuffer
    int iReceiveBufferLength;   // currently read data
    int iReceivedMessageLength; // length of the last message
    int   iCurRecSize;
    long dLastSendTime;       // time when last reliable message was sent
    long dLastMessage;        // time when last message was received
    unsigned int iSendSequence;           // current sendsequence for reliable messages
    unsigned int iUnreliableSendSequence; // current sendsequence for unreliable messages
    unsigned int iUnreliableReceiveSequence; // current receivesequence for unreliable messages
    unsigned int iBufferedSendSequence; // current sendsequenece for buffered messages
    unsigned int iBufferedReceivedSequence; // current receivesequenece for buffered messages
    unsigned int iReceiveSequence;        // current receivesequence for reliable messages
    long dAliveTimeout;        // after that time the server or client has timed out
    long dConnectRetry;        // how often attempt to retry to connect
    long dConnectTimeOut;      // timeout for a connection request
    long dAckTimeOut;          // how long wait before resending a message
    long dGuessReboot;
    long dMasterTimeout;
    long dMasterRetry;
    long dBufferedSize;
    long dBufferedQueue;

    unsigned int iPacketsSent;  // total number of sent packets
    unsigned int iPacketsReSent;// total number of resent packets
    unsigned int iShortPacketCount; // total number of packets that are shorter than the header itself
    unsigned int iLongPacketCount;
    unsigned int iPacketsReceived;
    unsigned int iDroppedDatagrams;
    unsigned int iReceivedDuplicateCount;
};

class CServerSocket : public CSocket
{
public:
    CServerSocket(void) {}
    CServerSocket(int iPort);
    ~CServerSocket(){}// {NetStat();}

	//CSocket *pAccept(void);
	// returns a new connection number if there is one pending, else NULL

	CSocket *pGetFirstSocket();
    CSocket *pGetNextSocket(); // returns pointer to connections
    void SetServerInfo(CPacket *pPacket){ pServerInfo = pPacket; }
    CPacket *pGetServerInfo(void){ return pServerInfo; } // serverinfo getter and setter
    //void SetMaster(CMasterAddress *pMaster);
    //CMasterAddress *pGetMaster();
    void SetUpMessage(CPacket *pPacket); // configure the use of the master server
    //void NetStat(); // prints the net statistics
    void RejectConnection(int iReSocket,sockaddr *pReAddr,char *pText);
    //CMasterAddress *pMa;
    CPacket *pServerInfo;
};


class C_FM_CLIENT
{
public:
    C_FM_CLIENT();
    ~C_FM_CLIENT();

	C_Toon		*toon;	// Current toon

	char		name[1024];

	void		VortexInsert(void);
	int			sid;
	char		access;
    void        Disconnect(void);
    void        SetState(eConnectionState eNewState);       // state of the connection
    void        SetSocket(CSocket *pNewSocket);             // sets the lowlevel netinterface
    CSocket     *pSocket;                                   // lowlevel network interface
    CSocket     *pGetSocket(void);                          // gets the lowlevel netinterface
    bool        bLoggedin;                                  // is the player logged in
    bool        bSystemBusy;                                // set if internal stuff to do
    int         iGetMessage(void);                          // tries to receive a message
    char        *get_remote_ip(void);
    C_FM_CLIENT *pNext;
    C_FM_CLIENT *pPrevious;

	void		Save(char *tname);
	void		Load(char *tname);

	char		*GetDB(char *vname);
	void		SetDB(char *var,char *val);

	void		LoadToon(int iSlot);

    void        do_net(void);

	void		LoginReply(int iLoginType,char * szAnswerMessage);

    CPacket     *SendPacket;

    // commands to push net messages the actual client follow :

    bool        AddGUIStump     (char *name,int x,int y,int x2,int y2,int props,char *media);
    bool        ModGUIStump     (char *name,int x,int y,int x2,int y2,int props,char *media);
    bool        DelGUIStump     (char *name);
    bool        GUIStumpCaption (char *name,char *caption);
    bool        AddGUIControl   (char *stump,char *name,int type,int props,int x,int y,int x2,int y2,char *media,char *value);
    bool        DelGUIControl   (char *stump,char *name);
    int         ModGUIControl   (char *stump,char *name);
    bool        GUIControlValue (char *stump,char *name,char *value);
    bool        ClearGUI        (void);

//    bool        SetDrawMap      (int dm);
//    bool        SetLimboState   (int lm);
//    bool        SetGameMode     (int gm);
//    bool        SetDayLight     (float r,float g,float b);

//    bool        SetCam          (int x,int y,int z, int ax,int ay,int az,int ox,int oy,int oz);
//    bool        MoveCamTo       (int x,int y,int z);
//    bool        ZoomCamTo       (int zoom);
//    bool        ScrollCamTo     (int x,int y,int z);

//    bool        VisRemove       (int ntt);
//    bool        VisMove         (int ntt,int x,int y,int z,char* media,int media_type,int head,int dir);

//    bool        SetMapTile      (int x,int y,int z,int bank,int tile);
//    bool        SetMapObject    (int x,int y,int z,int l,int bank,int obj);
//    bool        SetMapProp      (int x,int y,int z,int prop);
//    bool        SetMapVWidth    (int x,int y,int z,int v,int w);
//    bool        SetMapVHeight   (int x,int y,int z,int v,int h);
//    bool        SetMapVColor    (int x,int y,int z,int v,char r,char g,char b);

    eConnectionState eGetState(void);
    void		fm_client_init(void);
};

////////////////////////////////////////////////////
// server class

class CServer : public CServerInfo
{
public:
    CServer();
    CServer(int port);
    ~CServer();
    void            Accept(void);
    void            SendAll(CPacket *pPacket,float fBlockTime);
    void            Disconnect(C_FM_CLIENT *pClient,bool bsave);
    C_FM_CLIENT     *pFirstPlayer;
    C_FM_CLIENT     *pFirstDelete;
    CServerSocket   *pSocket;
    CServerSocket   *pGetSocket(void);
	//	CNPC			*pFirstNPC;
};

#endif
