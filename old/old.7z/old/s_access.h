/***************************************************************
 **                                                           **
 ** ****** *****    ****   ****  **   ** ****** *****  ****** **
 ** **     **  **  **  ** **  ** *** *** **     **  ** **     **
 ** ****   **  **  ****** **     ******* ****   **  ** ****   **
 ** **     *****   **  ** ** *** ** * ** **     *****  **     **
 ** **     **  **  **  ** **  ** **   ** **     **  ** **     **
 ** **     **  **  **  **  ****  **   ** ****** **  ** ****** **
 **                                                           **
 ***************************************************************
 ** FMGS Access Class                                         **
 ***************************************************************/

// NOTE/WARNING: Do NOT modify this file, or it will likely not work
/*
#ifndef _FM_GAME_SERVER_ACCESS
#define _FM_GAME_SERVER_ACCESS


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "global.h"
#include "fm_util.h"

class C_FM_Access_Var
{
public:
    C_FM_Access_Var();
    ~C_FM_Access_Var();
    char   name[256];
    u_int  value;
    C_FM_Access_Var *pNext;
};

class C_FM_Access
{
public:
    C_FM_Access();
    ~C_FM_Access();

    bool  flag_check(char *name,u_int compare_value);
    u_int flag_value(char *name);          // return access value
    void  flag_add(char *name,u_int value); // add new access type
    void  flag_del(char *name);
    void  flag_mod(char *name,u_int value);

    void  list_flags(void);        // return list of all access types
    void  load_flags(void);        // load access types
    void  save_flags(void);        // save access types
    void  clear_flags(void);       // clear access types

    char *group_name(u_int value); // return name by value
    u_int group_value(char *name); // return value by name
    void  group_add(char *name,u_int value);
    void  group_del(char *name);
    void  group_mod(char *name,u_int value);

    void  list_groups(void); 
    void  load_groups(void);
    void  save_groups(void);
    void  clear_groups(void);

    C_FM_Access_Var *flag;
    C_FM_Access_Var *first_flag;
    C_FM_Access_Var *group;
    C_FM_Access_Var *first_group;
};

extern C_FM_Access  *fm_access;


#endif
*/