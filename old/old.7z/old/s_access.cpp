/*
#include "s_access.h"

C_FM_Access  *fm_access;
//////////////////////////////////////////////////////////
C_FM_Access_Var::C_FM_Access_Var() { pNext=NULL; }
C_FM_Access_Var::~C_FM_Access_Var(){ }
//////////////////////////////////////////////////////////
C_FM_Access::C_FM_Access()
{
    flag=NULL;
    first_flag=NULL;
    group=NULL;
    first_group=NULL;
    flag=new C_FM_Access_Var;
    first_flag=flag;
    group=new C_FM_Access_Var;
    first_group=group;
    clear_flags();
    load_flags();
    clear_groups();
    load_groups();
}
//////////////////////////////////////////////////////////
C_FM_Access::~C_FM_Access() { }
//////////////////////////////////////////////////////////
void C_FM_Access::clear_flags(void)
{

}
//////////////////////////////////////////////////////////
void C_FM_Access::load_flags(void)
{

}
//////////////////////////////////////////////////////////
void C_FM_Access::clear_groups(void)
{

}
//////////////////////////////////////////////////////////
void C_FM_Access::load_groups(void)
{

}
//////////////////////////////////////////////////////////
char * C_FM_Access::group_name(u_int value)
{
    return "duh";
 
}
//////////////////////////////////////////////////////////
bool C_FM_Access::flag_check(char *name,u_int compare_value)
{

    return true;
}


  */

