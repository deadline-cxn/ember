/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_UTILITIES
#define _EMBER_UTILITIES

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLog;

#ifdef __cplusplus
extern "C"
{
#endif
    void    Log(char *fmt,...);
    void    LogC(char *fmt,...);
    void    DLog(char *fmt,...);
#ifdef __cplusplus
}
#endif

extern CLog *pLog;
extern bool bLog;


#endif // _EMBER_UTILITIES


