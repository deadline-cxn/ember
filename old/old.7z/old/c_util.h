/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_UTIL
#define _EMBER_UTIL

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "global.h"

//#include "c_gaf.h"
//#include "b_gui.h"


#ifdef __cplusplus
extern "C"
{
#endif


#ifdef __cplusplus
}
#endif

//class CC_Data;
//class CPacket;
//class CInetAddress;
//class C_FMMS;
//class C_FM_GUI;
//class C_FMGS;
//class C_FMMS;
// class CVector3;








#endif
