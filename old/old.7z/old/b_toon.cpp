/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#include "b_toon.h"
#include "dlstorm.h"

//////////////////////////////////////////////////////////
C_Toon::C_Toon(void)
{
	memset(t_name,0,32);
	t_race=0;
	t_class=0;
	t_level=0;
	t_gender=0;
	t_experience=0;
	t_experience_to_next_level=0;
	t_pvp=0;
	t_money=0;
	t_skill1=0;
	t_skill2=0;
	t_skill3=0;
	t_skill4=0;
	t_skill5=0;
	t_skill6=0;
	x=0;
	y=0;
	z=0;
	v_x=0; // facing vector
	v_y=0; // facing vector
	v_z=0; // facing vector
	c_x=0; // camera
	c_y=0; // camera
	c_z=0; // camera
	atr_str=0; // strength
	atr_int=0; // intelligence
	atr_spi=0; // spirit
	atr_con=0; // constitution
	atr_agi=0; // agility
	atr_wis=0; // wisdom
	atr_gui=0; // guile
	adj_str=0; // strength
	adj_int=0; // intelligence
	adj_spi=0; // spirit
	adj_con=0; // constitution
	adj_agi=0; // agility
	adj_wis=0; // wisdom
	adj_gui=0; // guile
	i_main_hand=0;
	i_off_hand=0;
	i_neck=0;
	i_head=0;
	i_hands=0;
	i_arms=0;
	i_chest=0;
	i_back=0;
	i_legs=0;
	i_feet=0;
	i_ring1=0;
	i_ring2=0;
	i_ring3=0;
	i_ring4=0;
	i_trinket1=0;
	i_trinket2=0;
	i_ear1=0;
	i_ear2=0;
	i_tabard=0;
	memset(p_name,0,32);
	p_renamed=0; // if no you can still rename your pet
	p_atr_str=0; // strength
	p_atr_int=0; // intelligence
	p_atr_spi=0; // spirit
	p_atr_con=0; // constitution
	p_atr_agi=0; // agility
	p_atr_wis=0; // wisdom
	p_atr_gui=0; // guile
	p_adj_str=0; // strength
	p_adj_int=0; // intelligence
	p_adj_spi=0; // spirit
	p_adj_con=0; // constitution
	p_adj_agi=0; // agility
	p_adj_wis=0; // wisdom
	p_adj_gui=0; // guile
}
//////////////////////////////////////////////////////////
C_Toon::~C_Toon()
{

}

#ifdef _EMBER_SERVER_
//////////////////////////////////////////////////////////
void C_Toon::Create(int slot)
{

}
//////////////////////////////////////////////////////////
void C_Toon::Save(int slot)
{

}

//////////////////////////////////////////////////////////
void C_Toon::Load(int slot)
{
    char In[1024]; memset(In,0,1024);
    char *Entry;

	FILE *fp=fopen(va("toon.%d.etf",slot),"rb");

	if(fp)
	{
		while(1)
		{
			if(!fgets(In,255,fp)) break;

			Entry = strtok(In,"=,[];");


			if(dlcs_strcasecmp(Entry,"name"))
			{
				Entry=strtok(NULL,"\n");
				if( Entry != NULL ) strcpy(t_name,Entry);
				else				memset(t_name,0,32);
			}
			if(dlcs_strcasecmp(Entry,"race"))
			{
				Entry=strtok(NULL,"\n");
				if( Entry != NULL ) t_race=atoi(Entry);
				else				t_race=0;
			}
			if(dlcs_strcasecmp(Entry,"class"))
			{
				Entry=strtok(NULL,"\n");
				if( Entry != NULL ) t_class=atoi(Entry);
				else				t_class=0;
			}
			if(dlcs_strcasecmp(Entry,"level"))
			{
				Entry=strtok(NULL,"\n");
				if( Entry != NULL ) t_level=atoi(Entry);
				else				t_level=0;
			}
			if(dlcs_strcasecmp(Entry,"gender"))
			{
				Entry=strtok(NULL,"\n");
				if( Entry != NULL ) t_gender=atoi(Entry);
				else				t_gender=0;
			}
			if(dlcs_strcasecmp(Entry,"experience"))
			{
				Entry=strtok(NULL,"\n");
				if( Entry != NULL ) t_experience=atoi(Entry);
				else				t_experience=0;
			}
			if(dlcs_strcasecmp(Entry,"experience_to_next_level"))
			{
				Entry=strtok(NULL,"\n");
				if( Entry != NULL ) t_experience_to_next_level=atoi(Entry);
				else				t_experience_to_next_level=0;
			}
			if(dlcs_strcasecmp(Entry,"pvp"))
			{
				Entry=strtok(NULL,"\n");
				if( Entry != NULL ) t_pvp=atoi(Entry);
				else				t_pvp=0;
			}
			if(dlcs_strcasecmp(Entry,"money"))
			{
				Entry=strtok(NULL,"\n");
				if( Entry != NULL ) t_money=atoi(Entry);
				else				t_money=0;
			}


		}


		fclose(fp);
	}


}
#endif
