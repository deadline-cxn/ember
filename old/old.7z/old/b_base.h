/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_BASE
#define _EMBER_BASE

//#include "global.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class C_FM_BASE
{
public:
    C_FM_BASE();
    virtual ~C_FM_BASE();

    char    name[1024];

    unsigned long  sid;
    struct  tm *creation_time;

    void fm_base_init(void);

    void set_name(char *nm);
};

#endif // _EMBER_BASE
