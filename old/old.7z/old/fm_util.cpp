/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#include "fm_util.h"
#include "dlstorm.h"
#include "c_log.h"

#ifdef _EMBER_CLIENT_
#include "c_data.h"
#include "b_gui.h"
#endif

#ifdef _EMBER_SERVER_
#include "ember_game_server.h"
#endif

CLog    *pLog;
bool    bLog;
extern C_FM_GUI *pGUI;
extern CC_Data *pClientData;

/**************************************
 ** Log text to console and log file **
 **************************************/
void Log(char *fmt, ...)
{
    if(!pLog) return;
    char ach[16384];
    va_list va;
    va_start( va, fmt );
    vsprintf( ach, fmt, va );
    va_end( va );
	if(ach[strlen(ach)-1]!='\n')
    strcat(ach,"\n");
    pLog->AddEntry(ach);
#ifdef _EMBER_SERVER_
    if(!bQuiet) printf(ach);
#endif
#ifdef _EMBER_CLIENT_
    if(pGUI) pGUI->ConsoleEntry(ach);
#endif
#ifdef _EMBER_MASTER_
    if(!bQuiet) printf(ach);
#endif
}
/**************************************
 ** Log one char to the logfile      **
 **************************************/
void LogC(char *fmt, ...)
{
    if(!pLog) return;
    char ach[16384];
    va_list va;
    va_start( va, fmt );
    vsprintf( ach, fmt, va );
    va_end( va );
    printf(ach);
    pLog->AddEntryNoTime(ach);
}
/**************************************
 ** Log text to console and log file **
 **************************************/
void DLog(char *fmt, ...)
{
    if(!pLog) return;
#ifdef _EMBER_CLIENT_
    if(pClientData) if(pClientData->cDebug!=2) return;
#endif
    char ach[16384];
    va_list va;
    va_start( va, fmt );
    vsprintf( ach, fmt, va );
    va_end( va );
    strcat(ach,"\n");
#ifdef _EMBER_CLIENT_
    if(pClientData)
        if(pClientData->cDebug>0)
        {
            //if(pGUI)
              //  pGUI->ConsoleBufferAdd(ach);
        }
    if(pClientData)
    {
        if(pClientData->cDebug>1)
            pLog->AddEntry(ach);
    }
    else
    {
        pLog->AddEntry("(No ClientData):%s",ach);
    }

#endif

#ifdef _EMBER_MASTER_
    if(!bQuiet) printf(ach);
    pLog->AddEntry(ach);
#endif
#ifdef _EMBER_SERVER_
    printf(ach);
    pLog->AddEntry(ach);
#endif
}

