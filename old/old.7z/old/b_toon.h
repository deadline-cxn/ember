/***************************************************************
 ** EMBER BASE TOON FILE                                      **
 ***************************************************************/

#ifndef _EMBER_BASE_TOON_H
#define _EMBER_BASE_TOON_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

////////////////////////////////////////////////////////////////////////////////////////////////////////

class C_Toon
{
public:
    C_Toon();
    ~C_Toon();

	int			t_sid;
	
	// basic information

	char		t_name[32];
	char		t_race;
	char		t_class;
	int			t_level;
	char		t_gender;
	float		t_experience;
	float		t_experience_to_next_level;
	float		t_pvp; // 0 or a countdown timer until it is turned off
	float		t_money;

	// skills
	int			t_skill1;
	int			t_skill2;
	int			t_skill3;
	int			t_skill4;
	int			t_skill5;
	int			t_skill6;

	// location information
	float		x;
	float		y;
	float		z;
	float		v_x; // facing vector
	float		v_y; // facing vector
	float		v_z; // facing vector
	float		c_x; // camera
	float		c_y; // camera
	float		c_z; // camera

	// attributes (base)
	int			atr_str; // strength
	int			atr_int; // intelligence
	int			atr_spi; // spirit
	int			atr_con; // constitution
	int			atr_agi; // agility
	int			atr_wis; // wisdom
	int			atr_gui; // guile

	// attributes (adjustments)
	int			adj_str; // strength
	int			adj_int; // intelligence
	int			adj_spi; // spirit
	int			adj_con; // constitution
	int			adj_agi; // agility
	int			adj_wis; // wisdom
	int			adj_gui; // guile

	// inventory

	int			i_main_hand;
	int			i_off_hand;
	int			i_neck;
	int			i_head;
	int			i_hands;
	int			i_arms;
	int			i_chest;
	int			i_back;
	int			i_legs;
	int			i_feet;
	int			i_ring1;
	int			i_ring2;
	int			i_ring3;
	int			i_ring4;
	int			i_trinket1;
	int			i_trinket2;
	int			i_ear1;
	int			i_ear2;
	int			i_tabard;

	// pet information
	char		p_name[32];
	bool		p_renamed; // if no you can still rename your pet

	// pet attributes (base)
	int			p_atr_str; // strength
	int			p_atr_int; // intelligence
	int			p_atr_spi; // spirit
	int			p_atr_con; // constitution
	int			p_atr_agi; // agility
	int			p_atr_wis; // wisdom
	int			p_atr_gui; // guile

	// pet attributes (adjustments)
	int			p_adj_str; // strength
	int			p_adj_int; // intelligence
	int			p_adj_spi; // spirit
	int			p_adj_con; // constitution
	int			p_adj_agi; // agility
	int			p_adj_wis; // wisdom
	int			p_adj_gui; // guile

#ifdef _EMBER_SERVER_
	void		Create(int slot);
	void		Save(int slot);
	void		Load(int slot);

#endif
};

#endif // _EMBER_BASE_TOON_H
