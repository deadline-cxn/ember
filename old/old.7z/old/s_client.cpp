/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#include "dl_db.h"
#include "s_client.h"
#include "fm_util.h"
#include "ember_game_server.h"
#include "s_server.h"
#include "b_map.h"
#include "dlstorm.h"

//////////////////////////////////////////////////////////
C_FM_CLIENT::C_FM_CLIENT(void) { fm_client_init(); }
//////////////////////////////////////////////////////////
void C_FM_CLIENT::fm_client_init(void)
{
    SendPacket=new CPacket(8192);
    pSocket = NULL;
    bLoggedin   = false;
    bSystemBusy = false;
	memset(name,0,1024);
    pNext=NULL;
    pPrevious=NULL;
}
//////////////////////////////////////////////////////////
C_FM_CLIENT::~C_FM_CLIENT() { DEL(SendPacket); DEL(pSocket); }
//////////////////////////////////////////////////////////
int C_FM_CLIENT::iGetMessage()
{    
    if(!pSocket) { Log("s_client.cpp -> C_FM_CLIENT::iGetMessage() tried to operate on a null socket..."); return 0; }
    int i;
    if (eGetState() == CON_NOTCONNECT) return 0;
    i = pSocket->iGetMessage();
    if(i==-1) i=0;
    return i;
}
//////////////////////////////////////////////////////////
eConnectionState C_FM_CLIENT::eGetState()
{
    if(!this)       return CON_NOTCONNECT;
    if(!pSocket)    return CON_NOTCONNECT;
    if(!bLoggedin)  return CON_LOGGINPROC;
    if(bSystemBusy) return CON_SYSBUSY;
                    return CON_CONNECTED;
}
//////////////////////////////////////////////////////////
void C_FM_CLIENT::SetState(eConnectionState eNewState)
{
    if((pSocket)&&(eNewState==CON_CONNECTED)) bLoggedin = true;
    if(eNewState == CON_NOTCONNECT)
    {
        bLoggedin = false;
        if(pSocket) DEL(pSocket);
    }
    if(eNewState == CON_SYSBUSY) bSystemBusy = true;
}
//////////////////////////////////////////////////////////
void C_FM_CLIENT::Disconnect()
{
    if(pSocket) { pSocket->Disconnect(); DEL(pSocket); }
}
//////////////////////////////////////////////////////////
CSocket *C_FM_CLIENT::pGetSocket() { return pSocket; }
//////////////////////////////////////////////////////////
void C_FM_CLIENT::SetSocket(CSocket *pNewSocket) { DEL(pSocket); pSocket = pNewSocket; }
//////////////////////////////////////////////////////////
void C_FM_CLIENT::VortexInsert(void)
{
	sid=GetSerialNumber(0);
}
//////////////////////////////////////////////////////////
char *C_FM_CLIENT::get_remote_ip()
{
    CInetAddress *rip;
    rip=pSocket->pGetAddress();

	Log(rip->pGetHostName());

	/// Log("%s",rip->pGetHostAddress());

    return 0;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::ClearGUI()
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_GUI);
    SendPacket->Write((char)FM_GUI_CLEAR_ALL);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::AddGUIStump(char *name,int x,int y,int x2,int y2,int props,char *media)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_GUI);
    SendPacket->Write((char)FM_GUI_STUMP_CREATE);
    SendPacket->Write((char *) name);
    SendPacket->Write((int)    x);
    SendPacket->Write((int)    y);
    SendPacket->Write((int)    x2);
    SendPacket->Write((int)    y2);
    SendPacket->Write((int)    props);
    SendPacket->Write((char *) media);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1 ;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::ModGUIStump(char *name,int x,int y,int x2,int y2,int props,char *media)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_GUI);
    SendPacket->Write((char)FM_GUI_STUMP_UPDATE);
    SendPacket->Write((char *) name);
    SendPacket->Write((int)    x);
    SendPacket->Write((int)    y);
    SendPacket->Write((int)    x2);
    SendPacket->Write((int)    y2);
    SendPacket->Write((int)    props);
    SendPacket->Write((char *) media);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::DelGUIStump(char *name)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_GUI);
    SendPacket->Write((char)FM_GUI_STUMP_REMOVE);
    SendPacket->Write((char *) name);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::GUIStumpCaption(char *name,char *caption)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_GUI);
    SendPacket->Write((char)FM_GUI_STUMP_CAPTION);
    SendPacket->Write((char *) name);
    SendPacket->Write((char *) caption);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::AddGUIControl(char *stump,char *name,int type,int x,int y,int x2,int y2,int props,char *media,char *value)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_GUI);
    SendPacket->Write((char)FM_GUI_CONTROL_CREATE);
    SendPacket->Write((char *) stump);
    SendPacket->Write((char *) name);
    SendPacket->Write((int)    type);
    SendPacket->Write((int)    x);
    SendPacket->Write((int)    y);
    SendPacket->Write((int)    x2);
    SendPacket->Write((int)    y2);
    SendPacket->Write((int)    props);
    SendPacket->Write((char *) media);
    SendPacket->Write((char *) value);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::DelGUIControl(char *stump,char *name)
{
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::GUIControlValue(char *stump,char *name,char *value)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_GUI);
    SendPacket->Write((char)FM_GUI_CONTROL_VALUE);
    SendPacket->Write((char *) stump);
    SendPacket->Write((char *) name);
    SendPacket->Write((char *) value);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////
/*bool C_FM_CLIENT::SetLimboState(int lm)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_FVM);
    SendPacket->Write((char)FVM_SET_LIMBO_STATE);
    SendPacket->Write((int)lm);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}*/
//////////////////////////////////////////////////////////
/*bool C_FM_CLIENT::SetDrawMap(int dm)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_FVM);
    SendPacket->Write((char)FVM_SET_MAP_DRAW);
    SendPacket->Write((char)dm);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}*//*
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::SetGameMode(int gm)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_CHANGE_MODE);
    SendPacket->Write((char)gm);
    SendPacket->Write((char)1);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::SetDayLight(float r,float g,float b)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_FVM);
    SendPacket->Write((char)FVM_SET_DAYLIGHT);
    SendPacket->Write((float)r);
    SendPacket->Write((float)g);
    SendPacket->Write((float)b);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::SetCam(int x,int y,int z,int ax,int ay,int az,int ox,int oy,int oz)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_FVM);
    SendPacket->Write((char)FVM_MOVECAM);
    SendPacket->Write((int)x);
    SendPacket->Write((int)y);
    SendPacket->Write((int)z);
    SendPacket->Write((int)ax);
    SendPacket->Write((int)ay);
    SendPacket->Write((int)az);
    SendPacket->Write((int)ox);
    SendPacket->Write((int)oy);
    SendPacket->Write((int)oz);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::MoveCamTo   (int x,int y,int z)
{
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::ZoomCamTo   (int zoom)
{
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::ScrollCamTo (int x,int y,int z)
{
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::VisRemove(int ntt)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_VIS_REMOVE);
    SendPacket->Write((int)ntt);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}
//////////////////////////////////////////////////////////

bool C_FM_CLIENT::VisMove(int ntt,int x,int y,int z,char* media,int media_type,int head,int dir)
{
    SendPacket->Reset();
    SendPacket->Write((char)NETMSG_VIS_UPDATE);
    SendPacket->Write((int)ntt);
    SendPacket->Write((int)x);
    SendPacket->Write((int)y);
    SendPacket->Write((int)z);
    SendPacket->Write((char *)media);
    SendPacket->Write((int)media_type);
    SendPacket->Write((int)head);
    SendPacket->Write((int)dir);
    this->pSocket->SendUnreliableMessage(SendPacket);
    return 1;
}*/
//////////////////////////////////////////////////////////
void C_FM_CLIENT::LoginReply(int iLoginType,char * szAnswerMessage)
{
	SendPacket->Reset();
	SendPacket->Write((char) NETMSG_LOGIN_REQUEST_REPLY);
	SendPacket->Write((char)   iLoginType);
	SendPacket->Write((char *) szAnswerMessage);
	SendPacket->Write((char *) VERSION);
	SendPacket->Write((int)    sid);
	SendPacket->Write((char *) "ember");//gmvar("sys.media"));
	SendPacket->Write((char *) "ember");//gmvar("sys.name"));
	SendPacket->Write((char *) "Defective Minds");//gmvar("sys.owner"));
	SendPacket->Write((int)    access);
	SendPacket->Write((char *) "User");//gmvar(va("sys.access[%d].name",access)));
	SendPacket->Write((char)   8);//atoi(gmvar("sys.charslots")));
	this->pSocket->SendUnreliableMessage(SendPacket);
}
//////////////////////////////////////////////////////////
/*bool C_FM_CLIENT::SetMapTile   (int x,int y,int z,int bank,int tile)
{
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::SetMapObject (int x,int y,int z,int l,int bank,int obj)
{
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::SetMapProp   (int x,int y,int z,int prop)
{
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::SetMapVWidth (int x,int y,int z,int v,int w)
{
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::SetMapVHeight(int x,int y,int z,int v,int h)
{
    return 1;
}
//////////////////////////////////////////////////////////
bool C_FM_CLIENT::SetMapVColor (int x,int y,int z,int v,char r,char g,char b)
{
    return 1;
}*/



void C_FM_CLIENT::LoadToon(int iSlot)
{
	char *thisdir=dlcs_getcwd();

//	DEL(toon);
//	toon=new C_Toon();

	dlcs_mkdir(va("data/users/%s",name));
	dlcs_chdir(va("data/users/%s",name));

//	toon->Load(iSlot);

	dlcs_chdir(thisdir);
}
//////////////////////////////////////////////////////////
void C_FM_CLIENT::do_net(void)
{
	CPacket *RecvData=NULL;
    char szTemp[1024];
    memset(szTemp,0,1024);
    char szTemp2[1024];
    memset(szTemp2,0,1024);
    char szTemp3[1024];
    memset(szTemp3,0,1024);
    char szTemp4[2048];
    memset(szTemp4,0,2048);

    int i,j,k;
    int x,y,z;
    int ax,ay,az;
    int bx,by,bz;
    int cx,cy,cz;
    int dx,dy,dz;
    int ex,ey,ez;
    int fx,fy,fz;
//
//	char *Entry;
//	FILE *fp;
	char In[1024];
	memset(In,0,1024);

	int iLoginType=255;
	int sid=0;
	char access=0;
	char *username;
	char *szPass;
	char szAnswerMessage[256];

    char cMsgType;
    double gx;

    u_char vx,vy,vz;

    i=j=k=x=y=z=ax=ay=az=bx=by=bz=cx=cy=cz=dx=dy=dz=ex=ey=ez=fx=fy=fz=0;

    C_FM_CLIENT *client=this;
    C_FM_CLIENT *other_client=0;

    if(client->pSocket)
    if(client->eGetState()!=CON_NOTCONNECT)
    {
        i=client->iGetMessage();
        //Log("iGetMessage=%d",i);
        if(i>0)
        {
            RecvData=client->pSocket->pGetMessage();
            cMsgType=RecvData->cRead();

            switch(cMsgType)
            {

                /*********************************************************************************
                 ** NETMSG_GUI                                                                  **
                 *********************************************************************************/

                case NETMSG_GUI:
                    strcpy(szTemp3,RecvData->pRead());
                    //l_interpret(va("world.client[%d]:clearformdata();",client->windex));
                    ax=RecvData->cRead(); // number of data to get
                    for(i=0;i<ax;i++)
                    {
                        strcpy(szTemp ,RecvData->pRead());
                        strcpy(szTemp2,RecvData->pRead());
                        //l_interpret(va("world.client[%d]:addformdata(\"%s\",\"%s\");",client->windex,szTemp,szTemp2));
                    }

                    //client->lua_script(szTemp3);
                    //}
                    //*/
                    break;

                /*********************************************************************************
                 ** NETMSG_GET_LOGIN_PROGRAM                                                    **
                 *********************************************************************************/

                case NETMSG_GET_LOGIN_PROGRAM:
                    /* Log("Hi");
                    Send.Reset();
                    Send.Write((char)NETMSG_GUI);
                    Send.Write((char)0);
                    Send.Write((char)0);                       
                    client->pSocket->SendUnreliableMessage((CPacket *)&Send); */
                    break;

                /*********************************************************************************
                 ** NETMSG_SERVERINFORMATION                                                    **
                 *********************************************************************************/

				case NETMSG_SERVERINFORMATION:

					// request basic server information

					Send.Reset();
					Send.Write((char)NETMSG_SERVERINFORMATION);

					/*
					// races

					Send.Write((char)fmgs->cRaces);

					fmgs->pRace=fmgs->pFirstRace;
					while(fmgs->pRace)
					{
						Send.Write((char)   fmgs->pRace->sid);
						Send.Write((char *) fmgs->pRace->name);
						fmgs->pRace=fmgs->pRace->pNext;
					}

					// classes

					Send.Write((char)fmgs->cClasses);

					fmgs->pClass=fmgs->pFirstClass;
					while(fmgs->pClass)
					{
						Send.Write((char)	fmgs->pClass->sid);
						Send.Write((char *) fmgs->pClass->name);
						fmgs->pClass=fmgs->pClass->pNext;
					}
					*/

					client->pSocket->SendUnreliableMessage((CPacket *)&Send);

					break;

                /*********************************************************************************
                 ** NETMSG_SERVER_INFO                                                          **
                 *********************************************************************************/

                case NETMSG_SERVER_INFO:
                    switch(RecvData->cRead())
                    {
                        case SI_GENERIC:
                            break;
                        default:
                            break;
                    }
                    break;
           

                /*********************************************************************************
                 ** NETMSG_RETRIEVECHARS                                                        **
                 *********************************************************************************/
        
                case NETMSG_RETRIEVECHARS:

				 	Log("NETMSG_RETRIEVECHARS: (%s)",client->name);
					

                    Send.Reset();
                    Send.Write((char)NETMSG_RETRIEVECHARS);
					Send.Write((char)MAX_TOONS);

					for(i=0;i<MAX_TOONS;i++)
					{
//						client->LoadToon(i);
//						Send.Write((char *)        client->toon->t_name); // name
//						Send.Write((char *)va("%d",client->toon->t_level)); // level
//						Send.Write((char *)va("%d",client->toon->t_race)); // race
//						Send.Write((char *)va("%d",client->toon->t_class)); // class
//						Send.Write((char *)va("%d",client->toon->t_gender)); // gender

					}

					client->pSocket->SendUnreliableMessage((CPacket *)&Send);

                    break;

                /*********************************************************************************
                 ** NETMSG_RETRIEVECHARINFO                                                     **
                 *********************************************************************************
                case NETMSG_RETRIEVECHARINFO:

                    // client->inactivity_event->reset_timer();
                    cx=RecvData->cRead();
                    if(client->in_limbo==false)
                    {
                        client->avatar->load(cx);
                        client->in_limbo=true;
                        Send.Reset();
                        Send.Write((char)NETMSG_RETRIEVECHARINFO);
                        Send.Write((char *)client->avatar->name);
                        Send.Write((int)client->sid);
                        Send.Write((char)client->avatar->direction);
                        Send.Write((int)15015);
                        Send.Write((int)15015);
                        Send.Write((int)15015);
                        client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                        MovePlayer(client,client->avatar->x,client->avatar->y,client->avatar->z,1);
                    }
                    break;

                /*********************************************************************************
                 ** NETMSG_LOCALCHAT                                                            **
                 *********************************************************************************

                case NETMSG_LOCALCHAT:  // Local Chat

                    // client->inactivity_event->reset_timer();
                    strcpy(szTemp,RecvData->pRead());
                    if((atoi(l_sys("log_local_chat"))?0:1))
                        Log("%s(%s)L\"%s\"",client->avatar->name,client->avatar->name,szTemp);
                    Send.Reset();
                    Send.Write((char)NETMSG_LOCALCHAT);
                    Send.Write((int)client->sid);
                    Send.Write((char *)szTemp);
                    client->avatar->chat_r=RecvData->cRead();
                    Send.Write((char) client->avatar->chat_r);   // Red element
                    client->avatar->chat_g=RecvData->cRead();
                    Send.Write((char) client->avatar->chat_g);   // Green element
                    client->avatar->chat_b=RecvData->cRead();
                    Send.Write((char) client->avatar->chat_b);   // Blue element
                    client->avatar->set_chat_font(RecvData->pRead());
                    Send.Write((char *) client->avatar->chat_font); // Font name

                    other_client=fmgs->pFirstPlayer;
                    while(other_client)
                    {
                        if( ( other_client->avatar->x >= client->avatar->x-GMP_MAPSIZE ) &&
                            ( other_client->avatar->x <= client->avatar->x+GMP_MAPSIZE ) &&
                            ( other_client->avatar->y >= client->avatar->y-GMP_MAPSIZE ) &&
                            ( other_client->avatar->y <= client->avatar->y+GMP_MAPSIZE ) &&
                            ( other_client->avatar->z == client->avatar->z    ) )
                            {
                                other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                            }
                        other_client=other_client->pNext;
                    }
                    
                    break;


                /*********************************************************************************
                 ** NETMSG_SYSTEMMSG                                                            **
                 *********************************************************************************/

                case NETMSG_SYSTEMMSG:  // Global Chat / System Message
                    
                    // client->inactivity_event->reset_timer();
                    strcpy(szTemp,RecvData->pRead());
                    //GlobalAnnounce(client,va("%s:%s",l_client_prop(windex,"name"),szTemp),ax,ay,az);
                    break;
   
                /*********************************************************************************
                 ** NETMSG_GENERIC_MSG                                                          **
                 *********************************************************************************/

                case NETMSG_GENERIC_MSG:
                    // client->inactivity_event->reset_timer();
                    strcpy(szTemp,RecvData->pRead());
                    memset(szTemp2,0,1024);
                    j=0;
                    for(i=0;i<strlen(szTemp);i++)
                    {
                        if(szTemp[i]=='\'')
                        {
                            szTemp2[j]='\\';
                            j++;
                            szTemp2[j]='\'';
                            j++;
                        }
                        else
                        {
                            szTemp2[j]=szTemp[i];
                            j++;
                        }
                    }
                    for(i=0;i<strlen(szTemp2);i++) szTemp2[i]=szTemp2[i+1];
					// should have a / in front, remove it

					
					
                    
					GlobalAnnounce(client,va("Yes!  you sent[%s]",szTemp2),255,255,0);
					
					//l_interpret(va("world.client[%d]:con_parse(\"%s\")",windex,szTemp2));



                    break;

                /*********************************************************************************
                 ** NETMSG_MOVEPLAYER                                                           **
                 *********************************************************************************/

                case NETMSG_MOVEPLAYER:

                    // given a starting location A
                    // and   an ending  location B
                    // the server will generate a path ((x,y) waypoints)
                    // and return it to the client
                    // if there is no path to the destination,
                    // the function will return 0
                    // location A and location B must be visible on the client's screen
                    
                    


                    /*
                    // Request for movement
                    // Store current client location here.

                    // client->inactivity_event->reset_timer();
                        
                    ax = client->avatar->x;
                    ay = client->avatar->y;
                    az = client->avatar->z;
                    
                    // Read requested move from data packet.
                    
                    dx = RecvData->cRead();

                    switch(dx)
                    {
                        case FM_NORTH:
                            client->avatar->y=client->avatar->y-1;
                            client->avatar->direction=FM_NORTH;
                            break;

                        case FM_SOUTH:
                            client->avatar->y=client->avatar->y+1;                                
                            client->avatar->direction=FM_SOUTH;
                            break;

                        case FM_EAST:
                            client->avatar->x=client->avatar->x+1;                                
                            client->avatar->direction=FM_EAST;
                            break;

                        case FM_WEST:
                            client->avatar->x=client->avatar->x-1;                                
                            client->avatar->direction=FM_WEST;
                            break;

                        case FM_NORTHWEST:                                
                            client->avatar->y=client->avatar->y-1;
                            client->avatar->x=client->avatar->x-1;
                            client->avatar->direction=FM_NORTHWEST;
                            break;

                        case FM_SOUTHWEST:
                            client->avatar->x=client->avatar->x-1;
                            client->avatar->y=client->avatar->y+1;
                            client->avatar->direction=FM_SOUTHWEST;
                            break;

                        case FM_NORTHEAST:
                            client->avatar->x=client->avatar->x+1;
                            client->avatar->y=client->avatar->y-1;
                            client->avatar->direction=FM_NORTHEAST;                                
                            break;

                        case FM_SOUTHEAST:
                            client->avatar->x=client->avatar->x+1;
                            client->avatar->y=client->avatar->y+1;
                            client->avatar->direction=FM_SOUTHEAST;
                            break;

                        default:
                            Log("%s(%s) Move Error! %d",client->avatar->name,client->avatar->name,dx);
                            break;
                    }
                    
                    // Get map sector for checking stuff

                    dy = pMap->LoadSector3D("map",  MapCoord(client->avatar->x),
                                                    MapCoord(client->avatar->y),
                                                    MapCoord(client->avatar->z));

                    dx=0; // teleport disable for now

                    // Check if tile is blocked
                    if( (client->game_state==PLAY) && 
                        (pMap->bIsBlocked(CamCoord(client->avatar->x),CamCoord(client->avatar->y))) )
                    {
                            // restore previous client location
                            client->avatar->x=ax;
                            client->avatar->y=ay;
                            client->avatar->z=az;
                            break;
                    }
                    else
                    {
                        MovePlayer(client,client->avatar->x,client->avatar->y,client->avatar->z,dx);
                    }

                    /*
                    dx = 0; // no teleports allowed in this server!
                    if(root->pSystem->iGetProperty("teleports"))
                    {
                        dx = pMap->bIsTeleport( client->avatar->x,
                                                client->avatar->y); // Check if on a teleport location here

                        if(dx) // reference teleport list to get the destination teleport location
                        {
                            pTeleport=pFirstTeleport;
                            while(pTeleport)
                            {
                                if( (pTeleport->iSourceX) == (client->pObjectRef->iGetProperty("x")) &&
                                    (pTeleport->iSourceY) == (client->pObjectRef->iGetProperty("y")) &&
                                    (pTeleport->iSourceZ) == (client->pObjectRef->iGetProperty("z")) )
                                    break;

                                pTeleport=pTeleport->pNext;
                            }

                            if(pTeleport)
                            {
                                client->pObjectRef->SetProperty("x",pTeleport->iDestinationX);
                                client->pObjectRef->SetProperty("y",pTeleport->iDestinationY);
                                client->pObjectRef->SetProperty("z",pTeleport->iDestinationZ);
                            }
                        }
                    }*/

                    

                    break;

                /*********************************************************************************
                 ** NETMSG_MODIFY_CHARACTER                                                     **
                 *********************************************************************************/

                case NETMSG_MODIFY_CHARACTER:
                    // client->inactivity_event->reset_timer();
                    /*
                                        
                    if(!DoesHaveAccess(client->cGetAccess(),"modify_character"))
                    {
                        // Player doesn't have access to change character information
                        // Send back a refuse request message
                        Announce(client,"Can't modify your character. You don't have the access.",255,0,0);
                        Log("%s(%s) tried to modify character!",client->avatar->name,client->avatar->name);
                        break;
                    }

                    Send.Reset();
                    Send.Write((char)NETMSG_MODIFY_CHARACTER);
                    Send.Write((int)RecvData->iRead());

                    switch(RecvData->cRead())
                    {
                        case MC_RACE:
                            client->SetRace(RecvData->cRead());
                            Send.Write((char)MC_RACE);
                            Send.Write((int)client->GetRace());
                            break;

                        case MC_GENDER:
                            client->SetGender(RecvData->cRead());
                            Send.Write((char)MC_GENDER);
                            Send.Write((char)client->GetGender());
                            break;

                        case MC_CLASS:
                            client->SetClass(RecvData->cRead());
                            Send.Write((char)MC_CLASS);
                            Send.Write((int)client->GetClass());
                            break;
                        
                        default:
                            break;
                    }

                    client->avatar->save("users");

                    // Send only to on screen players
                    // do really all players need this information?                         
                    // This packet will be sent when your characters appearance
                    // changes somehow, if there are players on screen, go ahead
                    // and describe the appearance so the client can render it

                    other_client=fmgs->pFirstPlayer;
                    while(other_client)
                    {
                        if( ( other_client->GetMapX() >= ( client->GetMapX()-1) ) &&
                            ( other_client->GetMapX() <= ( client->GetMapX()+1) ) &&
                            ( other_client->GetMapY() >= ( client->GetMapY()-1) ) &&
                            ( other_client->GetMapY() <= ( client->GetMapY()+1) ) &&
                            ( other_client->GetMapZ() ==   client->GetMapZ()    ) )
                        {
                            other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                        }
                        other_client=other_client->pNext;
                    }
                    */
                    break;

                /*********************************************************************************
                 ** NETMSG_CLIENTSHUTDOWN                                                       **
                 *********************************************************************************/

                case NETMSG_CLIENTSHUTDOWN:
                    other_client=fmgs->pFirstPlayer;
                    while(other_client)
                    {
                        if(other_client != client)
                        {
                            Send.Reset();
                            Send.Write((char)NETMSG_VIS_REMOVE);
                            //Send.Write((int)atoi(l_client_prop(windex,"sid")));
                            other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                        }
                        other_client=other_client->pNext;
                    }
                    other_client=client->pNext;
                    fmgs->Disconnect(client,1);
                    client=other_client;
                    return;
                    break;

                /*********************************************************************************
                 ** NETMSG_CREATE_CHARACTER                                                     **
                 *********************************************************************************

                case NETMSG_CREATE_CHARACTER:

                    // client->inactivity_event->reset_timer();
                    client->avatar->hail(RecvData->cRead());
                    strcpy(client->avatar->name,RecvData->pRead());

                    // call hook to do stuff with client here...

                    client->avatar->x=15015;
                    client->avatar->y=15015;
                    client->avatar->z=15015;

                    client->avatar->save(client->avatar->slot); // Save the character slot
                    Send.Reset();
                    Send.Write((char)NETMSG_CREATE_CHARACTER);
                    Send.Write((char)client->avatar->slot);
                    client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                    
                    break;

                /*********************************************************************************
                 ** NETMSG_DELETE_CHARACTER                                                     **
                 *********************************************************************************

                case NETMSG_DELETE_CHARACTER:

                    // client->inactivity_event->reset_timer();
                    cx = RecvData->cRead();
                    if(1)//!DoesHaveAccess(client->cGetAccess(),"fast_char_delete"))
                    {
                        client->avatar->load(cx);
                        //tTime=localtime(&client->CL_Data->tCreationTime);
                        //ax=tTime->tm_year;
                        //ay=tTime->tm_yday;
                        //time(&fmgsTime);
                        //tTime=localtime(&fmgsTime);
                        //bx=tTime->tm_year;
                        //by=tTime->tm_yday;
                        //if(bx==ax)
                        //{/
                        //    if( (by-ay) < l_sys("minimum_char_age)
                        //    {
                        //        sprintf(szTemp,"Character must age at least %s real days!",l_sys("minimum_char_age"));
                        //        Announce(client,szTemp,50,175,255);
                        //        break;
                        //    }
                        // }
                    }
                    client->avatar->wipe();
                    client->avatar->save(cx);
                    Send.Reset();
                    Send.Write((char)NETMSG_DELETE_CHARACTER);
                    Send.Write((char)1);
                    client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                    break;

                /*********************************************************************************
                 ** NETMSG_MODIFY_MAP                                                           **
                 *********************************************************************************

                case NETMSG_MODIFY_MAP:

                    // client->inactivity_event->reset_timer();

                    if(pMap==NULL) break;

                    cx=RecvData->cRead();      // Type of modification
                    cy=RecvData->cRead();      // boolean

                    ax=client->avatar->x;//RecvData->iRead(); // x
                    ay=client->avatar->y;//RecvData->iRead(); // y
                    az=client->avatar->z;//RecvData->iRead(); // z

                    pMap->LoadSector3D("map",MapCoord(ax),MapCoord(ay),MapCoord(az));

                    Send.Reset();
                    Send.Write((char)NETMSG_MODIFY_MAP);

                    if(1) //!DoesHaveAccess(client->cGetAccess(),"map_build"))
                    {
                        AdminToPlayer(client,"You don't have access to build the map.",255,0,0);
                        break;
                    }

                    switch(cx)
                    {
                        case GMP_PROPERTY_LIQUID:

                            pMap->SetLiquid(CamCoord(ax),CamCoord(ay),(cy?true:false));  // keep microsoft happy
                            Send.Write((char)GMP_PROPERTY_LIQUID);
                            Send.Write((char)cy);

                            break;

                        case GMP_PROPERTY_BLOCKED:

                            pMap->SetBlocked(CamCoord(ax),CamCoord(ay),(cy?true:false));  // keep microsoft happy                                
                            Send.Write((char)GMP_PROPERTY_BLOCKED);
                            Send.Write((char)cy);

                            break;

                        case GMP_PROPERTY_INDOORS:

                            break;

                        case GMP_PROPERTY_TELEPORT:
                            /*

                            Send.Write((char)GMP_PROPERTY_TELEPORT);
                            Send.Write((char)cy);

                            pTeleport=pFirstTeleport;
                            while(pTeleport)
                            {
                                if( (pTeleport->iSourceX  == ax) &&
                                    (pTeleport->iSourceY  == ay) &&
                                    (pTeleport->iSourceZ  == az) )
                                    break;
                                pTeleport=pTeleport->pNext;
                            }

                            if(pTeleport)
                            {
                                if(cy)
                                {
                                    strcpy(pTeleport->szName,RecvData->pRead());
                                    strcpy(pTeleport->szDestName,RecvData->pRead());
                                    pTeleport->iDestinationX=RecvData->iRead();
                                    pTeleport->iDestinationY=RecvData->iRead();
                                    pTeleport->iDestinationZ=RecvData->iRead();
                                    sprintf(szTemp,"teleports%c%d.cfg",PATH_SEP,pTeleport->iSourceX,pTeleport->iSourceY,pTeleport->iSourceZ);
                                    pTeleport->bSave(szTemp);
                                }
                                else
                                {                                        
                                    sprintf(szTemp,"teleports%c%d-%d-%d.ini",PATH_SEP,pTeleport->iSourceX,pTeleport->iSourceY,pTeleport->iSourceZ);
                                    pTeleport->bClear();
                                    remove(szTemp);
                                }

                                pMap->SetTeleport(ax,ay,(cy?true:false));                                    
                                break;
                            }

                            if(!cy)
                            {
                                pMap->SetTeleport(ax,ay,(cy?true:false));                                   
                                break;
                            }

                            i=0;

                            pTeleport=pFirstTeleport;
                            while(pTeleport)
                            {
                                if(pTeleport->iKey==NOT_A_TELEPORT)
                                    break;
                                i++;
                                pTeleport=pTeleport->pNext;
                            }

                            if(i>MAX_TELEPORTS)
                                break;

                            if(pTeleport)
                            {
                                pTeleport->iKey=i;

                                strcpy(pTeleport->szName,RecvData->pRead());

                                pTeleport->iSourceX=ax;
                                pTeleport->iSourceY=ay;
                                pTeleport->iSourceZ=az;

                                strcpy(pTeleport->szDestName,RecvData->pRead());

                                pTeleport->iDestinationX=RecvData->iRead();
                                pTeleport->iDestinationY=RecvData->iRead();
                                pTeleport->iDestinationZ=RecvData->iRead();

                                sprintf(szTemp,"teleports%c%d-%d-%d.ini",PATH_SEP,pTeleport->iSourceX,pTeleport->iSourceY,pTeleport->iSourceZ);
                                pTeleport->bSave(szTemp);

                                pMap->SetTeleport(ax,ay,(cy?true:false));
                                pMap->SaveSector3D("map",bx,by,bz);

                                if(pTeleport->pNext)
                                    break;

                                pTeleport->pNext = new CTeleport;
                            }
                            ////*
                            break;

                        default:
                            return;
                            break;
                    }

                    Send.Write((int)ax);
                    Send.Write((int)ay);
                    Send.Write((int)az);
         
                    // Send to all players

                    other_client=fmgs->pFirstPlayer;
                    while(other_client)
                    {
                        other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                        other_client=other_client->pNext;
                    }
                    pMap->SaveSector3D("map",MapCoord(ax),MapCoord(ay),MapCoord(bz));
                    break;

                /*********************************************************************************
                 ** NETMSG_SET_TILE                                                             **
                 *********************************************************************************/

                case NETMSG_SET_TILE:
                    // client->inactivity_event->reset_timer();
       
                    if(1)//!DoesHaveAccess(client->cGetAccess(),"map_build"))
                    {
                        AdminToPlayer(client,"You don't have access to build the map.",255,0,0);
                        // Log("%s(%s) tried to set map tile.",client->avatar->name,client->avatar->name);
                        break;
                    }

                    ax = RecvData->iRead(); // x
                    ay = RecvData->iRead(); // y
                    az = RecvData->iRead(); // z
                    i  = RecvData->cRead(); // bank
                    j  = RecvData->cRead(); // tile

                    // Log("%s(%s) set tile:%d %d %d %d %d %d [%d][%d]",client->avatar->name,client->avatar->name,ax,ay,az,bx,by,bz,i,j);

                    pMap->LoadSector3D("map",MapCoord(ax),MapCoord(ay),MapCoord(az));
                    pMap->SetTile(CamCoord(ax),CamCoord(ay),i,j);
                    pMap->SaveSector3D("map",MapCoord(ax),MapCoord(ay),MapCoord(az));

                    Send.Reset();
                    Send.Write((char)NETMSG_SET_TILE);
                    Send.Write((int)ax); 
                    Send.Write((int)ay);
                    Send.Write((int)az);
                    Send.Write((char)i);
                    Send.Write((char)j);
                
                    other_client=fmgs->pFirstPlayer;
                    while(other_client)
                    {
                        other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                        other_client=other_client->pNext;
                    }

                    break;

                /*********************************************************************************
                 ** NETMSG_SET_OBJECT                                                           **
                 *********************************************************************************/

                case NETMSG_SET_OBJECT:
                    // client->inactivity_event->reset_timer();

                    if(1) //!DoesHaveAccess(client->cGetAccess(),"map_build"))
                    {
                        AdminToPlayer(client,"You don't have access to build the map.",255,0,0);
                        break;
                    }

                    ax = RecvData->iRead();  // x
                    ay = RecvData->iRead();  // y
                    az = RecvData->iRead();  // z
                    i  = RecvData->cRead(); // bank
                    j  = RecvData->cRead(); // object
                    k  = RecvData->cRead(); // layer

                    pMap->LoadSector3D("map",MapCoord(ax),MapCoord(ay),MapCoord(az));
                    pMap->SetObj(ax,ay,i,j,k);
                    pMap->SaveSector3D("map",MapCoord(ax),MapCoord(ay),MapCoord(az));

                    Send.Reset();
                    Send.Write((char)NETMSG_SET_OBJECT);
                    Send.Write((int)ax);
                    Send.Write((int)ay);
                    Send.Write((int)az);
                    Send.Write((char)i);
                    Send.Write((char)j);
                    Send.Write((char)k);

                    other_client=fmgs->pFirstPlayer;
                    while(other_client)
                    {
                        other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                        other_client=other_client->pNext;
                    }   

                    break;


                /*********************************************************************************
                 ** NETMSG_SET_VERTEX                                                           **
                 *********************************************************************************/

                case NETMSG_SET_VERTEX:

                    // client->inactivity_event->reset_timer();

                    if(1) //!DoesHaveAccess(client->cGetAccess(),"map_build"))
                    {
                        AdminToPlayer(client,"You don't have access to build the map.",255,0,0);
                        break;
                    }

                    if(!pMapBuffer)
                    {
                        // Log("Attempt to set vertex on map that doesn't exist.");
                        break;
                    }

                    ax = RecvData->iRead();  // x
                    ay = RecvData->iRead();  // y
                    az = RecvData->iRead();  // z

                    cx = RecvData->cRead(); // what type of change
                    cy = RecvData->cRead(); // which vertex
                    vx = RecvData->cRead(); // red element
                    vy = RecvData->cRead(); // green element
                    vz = RecvData->cRead(); // blue element

                    LoadMap(ax,ay,az);
                
                    switch(cx)
                    {
                        case 0: // height                                
                            pMapBuffer->SetVertexHeight(CamCoord(ax),CamCoord(ay),cy,vx);
                            break;

                        case 1: // color/lighting
                            pMapBuffer->SetVertexColor(CamCoord(ax),CamCoord(ay),cy,vx,vy,vz);
                            break;

                        case 2: // width
                            pMapBuffer->SetVertexWidth(CamCoord(ax),CamCoord(ay),cy,vx);
                            break;

                        case 3: // relight the entire map sector with this color
                            pMapBuffer->ClearVertexColors(vx,vy,vz);
                            break;

                        default:
                            break;
                    }                        
                
                    SaveMap(ax,ay,az); 

                    Send.Reset();
                    Send.Write((char)NETMSG_SET_VERTEX);
                    Send.Write((int)ax);
                    Send.Write((int)ay);
                    Send.Write((int)az);
                    Send.Write((char)cx); // what type of change
                    Send.Write((char)cy); // which vertex
                    Send.Write((char)vx);
                    Send.Write((char)vy);
                    Send.Write((char)vz);

                    other_client=fmgs->pFirstPlayer;
                    while(other_client)
                    {
                        other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                        other_client=other_client->pNext;
                    }

                    break;

                
                /*********************************************************************************
                 ** NETMSG_HEARTBEAT                                                            **
                 *********************************************************************************/

                case NETMSG_HEARTBEAT:
                    /*
                    // client->inactivity_event->reset_timer();
                    client->bCheckHeartBeat=0; // OK, clear the heart beat check

                    // Reset packet & send status while i'm at it
                    Send.Reset();
                    Send.Write((char)NETMSG_CHAR_STATUS);
                    Send.Write((char *)client->avatar->name);
                    Send.Write((int)client->sid);
                    Send.Write((char)client->avatar->direction);
                    Send.Write((int)client->avatar->x);
                    Send.Write((int)client->avatar->y);
                    Send.Write((int)client->avatar->z);

                    client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                    */

                    break;
                
                /*********************************************************************************
                 ** NETMSG_FVM                                                                 **
                 *********************************************************************************/

                case NETMSG_FVM:

                    ax=RecvData->cRead();

                    switch(ax)
                    {
                        case FVM_GETTARGET:
//                                strcpy(client->CurrentTarget,RecvData->pRead());
//                                strcpy(client->Script,RecvData->pRead());
                            break;

                        case FVM_MOUSEINFO:
//                                client->MouseInfo.x=1; // RecvData->iRead();
//                                client->MouseInfo.y=1; // RecvData->iRead();
//                                client->MouseInfo.buttonstate=0; // RecvData->cRead();
//                                client->SetScript("onclick.fvm");
                            //pFVM->ExecuteScript(client);
                            break;

                        case FVM_GUIBUTTONPRESSED:
                            break;

                        default:
                            break;
                    }

                    break;
                
                /*********************************************************************************
                 ** NETMSG_PING                                                                 **
                 *********************************************************************************/

                case NETMSG_PING:
                    gx=RecvData->dwRead();
                    Send.Reset();
                    Send.Write((char)NETMSG_PING);
                    Send.Write((long)gx);
                    client->pSocket->SendUnreliableMessage((CPacket *)&Send);

                /*********************************************************************************
                 ** NETMSG_LOGIN_REQUEST                                                        **
                 *********************************************************************************/

                case NETMSG_LOGIN_REQUEST:

					memset(szAnswerMessage,0,256);
					strcpy(szAnswerMessage,"null");
					username = RecvData->pRead();
					szPass	 = RecvData->pRead();
					//Log("login... [%s][%s]",username,szPass);
					if((username==NULL) || (szPass==NULL))
					{
						client->LoginReply(BAD_LOGIN,"Bad network message");
						fmgs->Disconnect(client,0);
						RemoveAccount(username);
						break;
					}

					iLoginType=BAD_LOGIN;

					if(atoi(fmgs->players) > atoi(fmgs->maximum_players))
						iLoginType=TOO_MANY_PLAYERS;

					if(dlcs_strcasecmp(username,"system")) iLoginType=ALREADY_LOGGED_IN;
					if(dlcs_strcasecmp(username,"admin")) iLoginType=ALREADY_LOGGED_IN;
					if(dlcs_strcasecmp(username,"administrator")) iLoginType=ALREADY_LOGGED_IN;

					other_client=fmgs->pFirstPlayer;
					while(other_client)
					{
						if(dlcs_strcasecmp(other_client->name,username))
						{
							iLoginType=ALREADY_LOGGED_IN;
							break;
						}
						other_client=other_client->pNext;
					}

					if(iLoginType==BAD_LOGIN) 
					{
						memset(szTemp2,0,1024);

						if( dlcs_strcasecmp( db->parse(db->select(va("users name %s",username)),"password"),szPass))
						{
							iLoginType=GOOD_LOGIN;
						}
						else
						{
							iLoginType=BAD_LOGIN;
						}
					}

					switch(iLoginType)
					{
						case BAD_LOGIN:         strcpy(szAnswerMessage,"Incorrect password...");            break;
						case ALREADY_LOGGED_IN: strcpy(szAnswerMessage,"This user is already logged in from another machine...");       break;
						case ACCOUNT_EXPIRED:   strcpy(szAnswerMessage,"Your account has expired. Contact system administrator.");      break;
						case TOO_MANY_PLAYERS:  strcpy(szAnswerMessage,"Server is full. Too many       players already logged in...");  break;
						case GOOD_LOGIN:
							if(!strlen(username))
							{
								iLoginType=BAD_LOGIN;
								Log("bad login...");
								strcpy(szAnswerMessage,"Bad network try again.");
								break;
							}
							break;
						case NEW_ACCOUNT:
							if(dlcs_strcasecmp("yes",fmgs->allow_new_users))
							{
								iLoginType=BAD_LOGIN;
								strcpy(szAnswerMessage,va("Sign up for a new account on the webpage (%s)",fmgs->owner_website));
								break;
							}
							else
							{
								iLoginType=BAD_LOGIN;
								strcpy(szAnswerMessage,"Sorry, we're not accepting new accounts at this time. Try again later.");
								break;
							}
							break;
						default:
							break;
					}

					if(iLoginType==GOOD_LOGIN)
					{
						client->VortexInsert();
						strcpy(client->name,username);
					
						db->row_update(db->select(va("users name %s",client->name)),"last_login", dlcs_timestamp());
						db->row_update(db->select(va("users name %s",client->name)),"this_ip","127.0.0.1");
						db->row_update(db->select(va("users name %s",client->name)),"logged_in","yes");

						client->SetState(CON_CONNECTED);
						strcpy(szAnswerMessage,"Welcome to the server.");
						sid=client->sid;
						// access=client->access;
					}
					
					client->LoginReply(iLoginType,szAnswerMessage);

					if(iLoginType!=GOOD_LOGIN)
					{
						fmgs->Disconnect(client,0); RemoveAccount(username);
					}

                    break;

                /*********************************************************************************
                 ** NETMSG_LOGOUT                                                               **
                 *********************************************************************************/

                case NETMSG_LOGOUT:

						fmgs->Disconnect(client,1);

                    break;


                /*********************************************************************************
                 ** NETMSG_FILE_XFER                                                            **
                 *********************************************************************************/

                case NETMSG_FILE_XFER:

					//char *pFileBuf;
					//FILE *pFile;
					//bool bFileFail;
					
					switch(RecvData->cRead())
					{
								// NET_FILE_RES_MEDIA
								// NET_FILE_RES_SCRIPT
						/*

						case NET_FILE_NOP:
							break;

						case NET_FILE_START:
							// filename
							// filesize
							// start file, put a temporary sequencer in temp folder for the file
							// ie; hey.bmp will create temp/hey.bmp.sequence
							strcpy(szTemp1,RecvData->pRead());
							cx=RecvData->iRead();
							sprintf(szTemp2,"%s%ctemp%c%s.sequence",pClientData->FMDir,_PS,_PS,szTemp1);
							sprintf(szTemp3,"%s%ctemp%c%s",pClientData->FMDir,_PS,_PS,szTemp1);
							bFileFail=false;
							pFile=fopen(szTemp3,"wb");
							if(pFile)
							{
								fclose(pFile);
								pFile=fopen(szTemp2,"wt");
								if(pFile)
								{
									bx=1;
									fputs(va("%d\n%d\n",bx,cx),pFile);
									fclose(pFile);
									SendData.Reset();
									SendData.Write((char)NETMSG_FILE_XFER);
									SendData.Write((char *)szTemp1);
									SendData.Write((char)NET_FILE_START_OK);
									SendNetMessage(0);
								}
								else bFileFail=true;
							}
							else bFileFail=true;
							if(bFileFail)
							{
								SendData.Reset();
								SendData.Write((char)NETMSG_FILE_XFER);
								SendData.Write((char *)szTemp1);
								SendData.Write((char)NET_FILE_ERROR);
								SendNetMessage(0);
							}

							break;
							*/

						/*
						case NET_FILE_DATA:

							// sequence number
							// filename
							// data block (1024)

							ax=RecvData->iRead(); // sequence number
							strcpy(szTemp1,RecvData->pRead()); // filename
							pFileBuf=RecvData->pRead(NET_FILE_XFER_BLOCK_SIZE);
							sprintf(szTemp2,"%s%ctemp%c%s.sequence",pClientData->FMDir,_PS,_PS,szTemp1);
							sprintf(szTemp3,"%s%ctemp%c%s",pClientData->FMDir,_PS,_PS,szTemp1);
							bFileFail=false;
							pFile=fopen(szTemp2,"rb"); 
							if(pFile)
							{
								fgets(szTemp4,256,pFile); bx=atoi(szTemp4);
								fgets(szTemp4,256,pFile); cx=atoi(szTemp4);
								fclose(pFile);
							}
							else bFileFail=true;
							if(ax==bx)
							{
								pFile=fopen(szTemp3,"a");
								if(pFile)
								{
									fwrite(pFileBuf,NET_FILE_XFER_BLOCK_SIZE,1,pFile);
									fclose(pFile);
									pFile=fopen(szTemp2,"wt");
									if(pFile)
									{
										bx++;
										fputs(va("%d\n%d\n",bx,cx),pFile);
										fclose(pFile);
									}

									SendData.Reset();
									SendData.Write((char)NETMSG_FILE_XFER);
									SendData.Write((char)NET_FILE_DATA_OK);
									SendData.Write((char *)szTemp1);
									SendData.Write((int)bx);
								}
								else
								{
									bFileFail=true;
								}

							}
							if(bFileFail)
							{
								SendData.Reset();
								SendData.Write((char)NETMSG_FILE_XFER);
								SendData.Write((char)NET_FILE_DATA_RESEND);
								SendData.Write((char *)szTemp1);
								SendData.Write((int)bx);
							}
							break;

						case NET_FILE_ACK:
							break;
							
						case NET_FILE_ABORT:
							break;

						case NET_FILE_EOF:

							// sequence number
							// filename
							// size of data block
							// data block

							ax=RecvData->iRead(); // sequence number
							strcpy(szTemp1,RecvData->pRead()); // filename
							dx=RecvData->iRead();
							pFileBuf=RecvData->pRead(dx);
							sprintf(szTemp2,"%s%ctemp%c%s.sequence",pClientData->FMDir,_PS,_PS,szTemp1);
							sprintf(szTemp3,"%s%ctemp%c%s",pClientData->FMDir,_PS,_PS,szTemp1);
							bFileFail=false;
							pFile=fopen(szTemp3,"a");
							if(pFile)
							{
								fwrite(pFileBuf,dx,1,pFile);
								fclose(pFile);
								remove(szTemp2);
							}
							else
							{
								SendData.Reset();
								SendData.Write((char)NETMSG_FILE_XFER);
								SendData.Write((char)NET_FILE_EOF_RESEND);
								SendData.Write((char *)szTemp1);
							}
							break;

						case NET_FILE_RESUME:
							break;
							*/

						case NET_FILE_START_OK:
							break;

						default:
							break;

						}


                    break;

                /*********************************************************************************
                 ** NETMSG_NOP                                                                  **
                 *********************************************************************************/

                case NETMSG_NOP:
                    if (strcmp(RecvData->pRead(),"1234567890")==0)
                    {
                        Send.Reset();
                        Send.Write((char)NETMSG_NOP);
                        Send.Write("0987654321");
                        if(client->pSocket->bCanSendMessage())
                            client->pSocket->SendUnreliableMessage(&Send);
                    }
                    break;


                default:
                    break;
            }
        }

        // Check for inactivity

        //if(client->inactivity_event->expired())
        //{
            //Log("duh...");
            // client->inactivity_event->reset_timer();
            //if(client->in_limbo==false)
            //{
                // client->inactivity_event->reset_timer();
                /*
                //Send.Reset();
                //Send.Write((char)NETMSG_HEARTBEAT);
                //Send.Write((int)1);
                //client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                //client->dwHeartBeatTimer=GetTickCount(); // Time function only works in windows
                //client->bCheckHeartBeat=1;
                

                if(1)//!DoesHaveAccess(client->cGetAccess(),"timeout_override"))
                {
                    if(strlen(client->avatar->name) && strlen(client->avatar->name))
                    {
                        // Log("%s(%s) being kicked due to inactivity.",client->avatar->name,client->avatar->name);
                        // client->inactivity_event->reset_timer(); //to prevent server from doing this twice (or more)

                        other_client=fmgs->pFirstPlayer;
                        while(other_client)
                        {
                            // change to only send to onscreen players later...
                            if(other_client != client)
                            {
                                Send.Reset();
                                Send.Write((char)NETMSG_VIS_REMOVE);
                                Send.Write((int)client->sid);
                                other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                            }
                            other_client=other_client->pNext;
                        }
                        // send shutdown to client
                        Send.Reset();
                        Send.Write((char)NETMSG_CLIENTSHUTDOWN);
                        Send.Write((int)client->sid);
                        Send.Write((char *)"Inactivity"); // reason
                        client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                        // Player disconnect here
                        other_client=fmgs->pFirstPlayer;
                        while(other_client)
                        {
                            // change to only send to onscreen players later...
                            if(other_client != client)
                            {
                                Send.Reset();
                                Send.Write((char)NETMSG_VIS_REMOVE);
                                Send.Write((int)client->sid);
                                other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
                            }
                            other_client=other_client->pNext;
                        }
                        Logout(client);
                    }
                }
                */
          //  }
        //}
        // Check for heartbeats and remove if not found
        
//            if((GetTickCount()-client->dwHeartBeatTimer>10000) && // 10 seconds should be enough
//                (client->bCheckHeartBeat) )
//            {
//                if(client->bInGame)
//                {
                // add in ability to check more than once, say three or four times before it logs out.
//                    // The client is no longer connected
                //other_client=fmgs->pFirstPlayer;
                //while(other_client)
                //{
                    // change to only send to onscreen players later...
                  //  if(other_client != client)
                    //{
                      //  Send.Reset();
                        //Send.Write((char)NETMSG_VIS_REMOVE);
                        //Send.Write((int)client->sid);
                        //other_client->pSocket->SendUnreliableMessage((CPacket *)&Send);
//                        }
//                      other_client=other_client->pNext;
//                }
  //              Logout(client);
    //        }
      //  }

        // Other System checks here, (Serverside player heartbeat)

        //if(client->in_limbo==false)
        //{
            /*
            if(GetTickCount()-client->dwSystemCheck>5000)
            {
                client->dwSystemCheck=GetTickCount();
            }
            */
        //}
    }

}
