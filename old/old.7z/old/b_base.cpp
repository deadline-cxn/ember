/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#include "b_base.h"
#include <string.h>
#include <io.h>
#include <time.h>
//////////////////////////////////////////////////////
C_FM_BASE::C_FM_BASE()
{
    fm_base_init();
}
//////////////////////////////////////////////////////
void C_FM_BASE::fm_base_init(void)
{
    memset(name,0,64);
    sid=0;
    time_t bc_time; time(&bc_time);
    creation_time=localtime(&bc_time);
}
//////////////////////////////////////////////////////
C_FM_BASE::~C_FM_BASE()
{

}

void C_FM_BASE::set_name(char *nm)
{
    strcpy(name,nm);
}
