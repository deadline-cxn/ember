/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_ABILITY
#define _EMBER_ABILITY

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAbility
{
public:
    CAbility();
    virtual ~CAbility();
    char    name[64];
    unsigned long  sid;
   
};

#endif // _EMBER_ABILITY
