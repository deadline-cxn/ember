
#ifdef __linux__

#include "global.h"
#include "dlstorm.h"
#include "dlstorm_lib.h"
#include "fm_util.h"

extern void ConsoleSetup(void);
extern void ConsoleShutDown(void);
extern void LoadPlugIns(void);
extern void UnLoadPlugIns(void);

#endif

