/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_NPC
#define _EMBER_NPC

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "b_toon.h"

class CNPC : public C_Toon
{
public:
    CNPC();
    virtual ~CNPC();

	long	sid;

	CNPC *pNext;

};

#endif // _EMBER_NPC