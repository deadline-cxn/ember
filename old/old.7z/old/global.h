/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_GLOBALS_H
#define _EMBER_GLOBALS_H

#include "dlstorm_lib.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define VERSION             "11.09.21"    // Version format change to vYY.MM.DDa
//#define NET_REVISION        "01"            // Network protocol version

#define EGC_REVISION        "00"
#define EGS_REVISION        "00"
#define EMS_REVISION        "00"

#define NAME   "Mantra"
#define TITLE  "Mantra"
#define AUTHOR "Seth Parson"

#define SCREEN_WIDTH  800
#define SCREEN_HEIGHT 600
#define SCREEN_COLORS 16


//////////////////////////////////////////////////////////////////////////////////////////////////
// Maximum values

#define MAX_SERVERS					1024    // Servers that can be listed
#define MAX_TOONS					8		// Character slots per server
#define MAX_PLAYERS					100		// Players per server

#define MAX_CLANS					512		// Clans per server
#define MAX_GUILDS					32		// Guilds per server
#define MAX_ACTIONS					128		// Actions that a player can perform
#define MAX_CLIENT_ITEMS		    4096	// Items per server/mission (Client Side)
#define MAX_ITEM_STORE				512     // Item Storage -> unique item types (Server Side)
#define MAX_INVENTORY_ITEMS         512     // Player inventory items
#define MAX_CONTAINER_ITEMS         512     // Container items
#define MAX_TILE_ITEMS              32      // Items per map tile
#define MAX_SERVER_ITEMS			4096  	// Total number of active items on the server world (No more than 65535!)
#define MAX_RACES					32   	// Races per server/mission
#define MAX_RACE_ADJ				16		// Special attributes/skills adjustments per race
#define MAX_RACE_BIAS				16		// Race biases per race
#define MAX_CLASSES					128     // Classes per server/mission
#define MAX_SKILLS					128		// Skills per server/mission
#define MAX_MAGIC					16		// Magic schools per server
#define MAX_SPELL_LEVEL				16		// Spell levels per magic school
#define MAX_SPELLS					16		// Spells per level (16x16x16 = 4096 spells - should be more than plenty)
#define MAX_ATTRIBUTES				16		// Number of attributes per server/mission
#define MAX_WEAPON_RANGE			32		// Max weapon range for missle weapons
#define MAX_TREASURE_TYPES			2048	// Different treasure types that can be aquired
#define MAX_CHAT_BUFFER				10		// Show some chat lines on the screen
#define MAX_ENTITIES				512		// Maximum entities on screen



#define MAX_WAV_BUFFER				64		// How many sounds can be played at one time
#define MAX_AI_WAYPOINTS			32		// Waypoints
#define MAX_MONEY_TYPES				16		// Different monetary units
#define MAX_ACCESS_GROUPS			256 	// Access groups
#define MAX_ATTRIBUTE_POINTS		256		// Distributable attribute points


#define	MAX_STRING_CHARS	        1024	// Length of a string
#define	MAX_STRING_TOKENS	        256		// Tokens
#define	MAX_TOKEN_CHARS		        1024	// Length of token
#define MAX_FVM                     512     // FVM files that can be loaded into memory

#define MAX_ICONS                   128     // System Icons
#define MAX_PROFILES                32      // max login profiles




#define FM_NORTH        5
#define FM_NORTHEAST    6
#define FM_NORTHWEST    4
#define FM_SOUTH        1
#define FM_SOUTHEAST    0
#define FM_SOUTHWEST    2
#define FM_EAST         7
#define FM_WEST         3

#ifndef NULL
#define NULL 0
#endif




// Login results

#define GOOD_LOGIN            1
#define BAD_LOGIN             2
#define NEW_ACCOUNT           3
#define ALREADY_LOGGED_IN     4
#define TOO_MANY_PLAYERS      5
#define SERVER_MAXXED_OUT     5
#define ACCOUNT_EXPIRED       6
#define MASTER_LOGIN          7



typedef enum {



} eCtlMessages;

typedef enum
{
    NET_HOSTPORT,
    NET_ALIVETIMEOUT,
    NET_CONNECTRETRY,
    NET_CONNECTTIMEOUT,
    NET_ACKTIMEOUT,
    NET_GUESSREBOOT,
    NET_MASTERRETRY,
    NET_MASTERTIMEOUT,
    NET_MAXBACKUPSIZE,
    NET_MAXBACKUPQUEUE,
    NET_LASTOPTION,
}eNetOptions;



//  NETMSG_MODE_CHANGE,

/*  NETMSG_ITEM_REMOVE,
    NETMSG_ITEM_MOVE,
    NETMSG_ITEM_CREATE,
    NETMSG_ITEM_LIST,
    NETMSG_ITEM_INFO,
    NETMSG_ITEM_USE, */

typedef enum{
    FVM_NOP=0,
    FVM_PLAYSOUND,
    FVM_PLAYMUSIC,
    FVM_LOADBACKGROUND,
    FVM_MOUSEINFO,
    FVM_GUICOMPONENT,
    FVM_PROMPT,
    FVM_GUIBUTTONPRESSED,
    FVM_GETTARGET,
    FVM_MOVECAM,
    FVM_SET_MAP_DRAW,
    FVM_SET_GAME_MODE,
    FVM_SET_DAYLIGHT,
    FVM_SET_LIMBO_STATE,

} tFVMstuff;



typedef enum{
    NET_FILE_NOP=0,
    NET_FILE_START,
	NET_FILE_START_OK,
    NET_FILE_DATA,
	NET_FILE_DATA_OK,
	NET_FILE_DATA_RESEND,
    NET_FILE_ACK,
    NET_FILE_ABORT,
    NET_FILE_EOF,
	NET_FILE_EOF_RESEND,
    NET_FILE_RESUME,
	NET_FILE_ERROR,
} tXferMode;

typedef enum{
    NET_FILE_RES_NONE=0,
    NET_FILE_RES_MEDIA,
    NET_FILE_RES_SCRIPT,
} tXferType;



typedef enum
{
    LM_NONE=0,
    LM_INTERNET,
    LM_FAVORITES,
    LM_LOCAL
} LMODE;


#endif // _EMBER_GLOBALS_H
