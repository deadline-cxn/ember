/***************************************************************
 **      EMBER                                                **
 ***************************************************************/
#include "c_map.h"
#include "fm_util.h"
#include "b_vis.h"
///////////////////////////////////////////////////////////////////////
CC_Map::CC_Map()
{
	TileWidth   = 0;
	TileHeight  = 0;
    SIZE=1;
    pMapData    = NULL;// new MAPDATA[SIZE];
	pItemData   = NULL;//new ITEMDATA[SIZE];

    VISData = 0;
    VISData = new iVISData[SIZE+1];
    for(int i=0;i<SIZE;i++)
    {
        VISData[i].pVISData=0;
        VISData[i].pFirstVISData=0;
    }

    pNext=NULL;
    pPrevious=NULL;
    iKey=0;
}
///////////////////////////////////////////////////////////////////////
CC_Map::~CC_Map() { CleanUp(); }
///////////////////////////////////////////////////////////////////////
// Clean up the map data, tile, and object banks
void CC_Map::CleanUp(void)
{
    if(pMapData)
    {
        delete [] pMapData;
        pMapData=NULL;
    }
    CEmMapObject *pHi=NULL;
    CEmMapObject *pFirstHi=NULL;
    int j=0;
    if(pItemData)
    {
        for(int i=0;i<SIZE;i++)
        {
            if(pItemData[i].pFirstItem)
            {
                pItemData[i].pItem=pItemData[i].pFirstItem;
                while(pItemData[i].pItem)
                {
                    pHi=pItemData[i].pItem;
                    if(!pFirstHi)
                    {
                        pFirstHi=pItemData[i].pItem;
                    }
                    pHi=pHi->pNext;
                    pItemData[i].pItem=pItemData[i].pItem->pNext;
                    j++;
                }
            }
        }
        delete [] pItemData;
        pItemData=NULL;
        pHi=pFirstHi;
        while(pHi)
        {
            pFirstHi=pHi;
            pHi=pHi->pNext;
            DEL(pFirstHi);
        }
    } 

    CC_M_VIS_DATA *del_vis=0;
    if(VISData)
    {
        for(j=0;j<SIZE;j++)
        {
            VISData[j].pVISData=VISData[j].pFirstVISData;
            while(VISData[j].pVISData)
            {
                del_vis=VISData[j].pVISData;
                VISData[j].pVISData=VISData[j].pVISData->next;
                DEL(del_vis);
            }
        }
        delete [] VISData;
        VISData=0;
    }
}
///////////////////////////////////////////////////////////////////////
// Create a new map, and fill it with a certain tile
bool CC_Map::bInitialize(int x, int y, u_char bank, u_char tile)
{
    CleanUp();
    int i;
	Width  = x;
	Height = y;
    SIZE = Width * Height;
    
    if(pMapData)  delete [] pMapData;
    pMapData = new MAPDATA[SIZE];
    if(!pMapData) return false;

    if(pItemData) delete [] pItemData;
    pItemData = new ITEMDATA[SIZE];
	if(pItemData==NULL) return false;

    for(i=0;i<SIZE;i++)
    {
        pItemData[i].pItem      = NULL;
        pItemData[i].pFirstItem = NULL;
        pItemData[i].pItem      = new CEmMapObject;
        pItemData[i].pFirstItem = pItemData[i].pItem;
    }
    ClearVertexColors();
    ClearVertexHeights();
    ClearVertexWidths();
    ClearProperties();
    SetScrollX(0);
    SetScrollY(0);
    SetColorKey(LONGRGB(0,0,0),true);
    FillTiles(bank,tile);
    if(VISData)
    {
        delete [] VISData;
        VISData=0;
    }
    VISData = 0;
    VISData = new iVISData[SIZE+1];
    for(i=0;i<SIZE;i++)
    {
        VISData[i].pVISData=0;
        VISData[i].pFirstVISData=0;
    }
    return true;
}

///////////////////////////////////////////////////////////////////////
// Set the colorkey color for tiles and objects BMP's
void CC_Map::SetColorKey(long color, bool yesno)
{
	ColorKey=color;
	ColorKeyActive = yesno;
}


///////////////////////////////////////////////////////////////////////
// Sets the tiledimensions that the Draw routines use
void CC_Map::SetTileDimensions(int iTWidth, int iTHeight)
{
	TileWidth	= iTWidth;
	TileHeight	= iTHeight;
}

///////////////////////////////////////////////////////////////////////
// Sets where on the screen to draw, and how many tiles to draw in x and y directions
void CC_Map::SetMapDraw(int sx, int sy, int tx, int ty)
{
	ScreenX = sx;
	ScreenY = sy;
	TilesToDrawX = tx;
	TilesToDrawY = ty;
}

///////////////////////////////////////////////////////////////////////
// Get Tiles to draw X
short CC_Map::GetTilesToDrawX(void)
{
	return TilesToDrawX;
}

///////////////////////////////////////////////////////////////////////
// Get Tiles to draw Y
short CC_Map::GetTilesToDrawY(void)
{
	return TilesToDrawY;
}

///////////////////////////////////////////////////////////////////////
// Get ScreenX (Position on the screen where the map drawing starts)
int	CC_Map::GetScreenX(void)
{
	return ScreenX;
}

///////////////////////////////////////////////////////////////////////
// Get ScreenY (Position on the screen where the map drawing starts)
int	CC_Map::GetScreenY(void)
{
	return ScreenY;
}


///////////////////////////////////////////////////////////////////////
// Get the map's tile width in pixels
int	CC_Map::GetTileWidth(void)
{
	return TileWidth;
}

///////////////////////////////////////////////////////////////////////
// Get the map's tile height in pixels
int	CC_Map::GetTileHeight(void)
{
	return TileHeight;
}

///////////////////////////////////////////////////////////////////////
// Get ScrollX position
int CC_Map::GetScrollX(void)
{
	return ScrollX;
}

///////////////////////////////////////////////////////////////////////
// Get ScrollY position
int CC_Map::GetScrollY(void)
{
	return ScrollY;
}

///////////////////////////////////////////////////////////////////////
// Set ScrollX position
void CC_Map::SetScrollX(int sx)
{
	ScrollX = sx;
}

///////////////////////////////////////////////////////////////////////
// Set ScrollY position
void CC_Map::SetScrollY(int sy)
{
	ScrollY = sy;
}

///////////////////////////////////////////////////////////////////////
// Scroll the map by (x,y) at the rate of scrollspeed
// This routine is for top down map view only
bool CC_Map::Scroll(int x, int y, int scrollspeed)
{
	// insert check for scrollspeed here based on GetTickCount(); for timing ??
	bool rtrn=false;
	ScrollX+=(x*scrollspeed);
	ScrollY+=(y*scrollspeed);
	if(ScrollX >= TileWidth)
	{
		ScrollX-=TileWidth;
		X-=1;
		rtrn=true;
	}
	if(ScrollX<1)
	{
		ScrollX=TileWidth-ScrollX-scrollspeed;
		X+=1;
		rtrn=true;
	}
	if(ScrollY >= TileHeight)
	{
		ScrollY-=TileHeight;
		Y-=1;
		rtrn=true;
	}
	if(ScrollY<1)
	{
		ScrollY=TileHeight-ScrollY-scrollspeed;
		Y+=1;
		rtrn=true;
	}
	return rtrn;
}

///////////////////////////////////////////////////////////////////////
// Scroll the map by (x,y) at the rate of scrollspeed
// This routine is for isometric view only
int CC_Map::ScrollIso(u_char SCRDIR, int speed)
{
/*
                                Scroll NorthWest (Y+1) 
                                |
                        
       Scroll West (X+1,Y+1)    *     Scroll North (X-1,Y+1)
                            \  ***  /
                              *****
                             *******
  Scroll SouthWest (X+1) -  *********  - Scroll NorthEast (X-1)
                             *******
                              *****
                            /  ***  \ 
	 Scroll South (X+1,Y-1)     *     Scroll East (X-1,Y-1)
  
                                |
                                Scroll SouthEast (Y-1)


  Deadline

 */

	switch(SCRDIR)
	{
		case FM_NORTH:
			ScrollX-=speed;
			ScrollY+=speed;
			if(ScrollX < -(TileWidth/2))
			{
				ScrollX=0;
				ScrollY=0;
				Y--;
				return true;
			}
			break;

		case FM_SOUTH:
			ScrollX+=speed;
			ScrollY-=speed;
			if(ScrollX > (TileWidth/2))
			{
				ScrollX=0;
				ScrollY=0;
				Y++;
				return true;
			}
			break;

		case FM_EAST:
			ScrollX-=speed;
			ScrollY-=speed;
			if(ScrollX < -(TileWidth/2))
			{
				ScrollX=0;
				ScrollY=0;
				X++;				
				return true;
			}
			break;

		case FM_WEST:
			ScrollX+=speed;
			ScrollY+=speed;
			if(ScrollX > (TileWidth/2))
			{
				ScrollX=0;
				ScrollY=0;
				X--;				
				return true;
			}
			break;

		case FM_NORTHWEST:
			ScrollY+=speed;
			if(ScrollY > (TileHeight))
			{
				ScrollY=0;
				ScrollX=0;
				X--;
				Y--;
				return true;
			}
			break;

		case FM_NORTHEAST:
			ScrollX-=speed;
			if(ScrollX < -(TileWidth))
			{
				ScrollX=0;
				ScrollY=0;
				X++;
				Y--;
				return true;
			}
			break;

		case FM_SOUTHWEST:
			ScrollX+=speed;
			if(ScrollX > (TileWidth))
			{
				ScrollX=0;
				ScrollY=0;
				X--;
				Y++;
				return true;
			}
			break;

		case FM_SOUTHEAST:
			ScrollY-=speed;
			if(ScrollY < -(TileHeight))
			{
				ScrollX=0;
				ScrollY=0;
				X++;
				Y++;
				return true;
			}
			break;

		default:
			break;
	}

	return false;
}

/*
///////////////////////////////////////////////////////////////////////
// Draw a normal top down map. This method is for games like:
// Chess			Sonic Hedgehog
// Pac-Clones		Spy Hunter
void CC_Map::Draw(CDirectDrawSurface* DSurface)
{
	int x,y,dt;
	for(x=0;x<TilesToDrawX+1;x++)
	{
		for(y=0;y<TilesToDrawY+1;y++)
		{
			dt = X + x + ((Y + y) * Width);
			if(dt<0) dt=0;
			if(dt>(Width*Height) ) dt=Width*Height;
//			TileBank[MapData[dt].TileList.TileBank+(MapData[dt].TileList.Tile*BANKMAX)].Draw(DSurface, ScrollX+ScreenX+(X*TileWidth), ScrollY+ScreenY+(y*TileHeight));
		}
	}
}

///////////////////////////////////////////////////////////////////////
// Draw the first layer of Isometric Map one at a time. 
// This is so that you can put players and monsters in to the drawing loop so
// as not to make them appear on top of everything.
//HRESULT CC_Map::Draw_Isometric_Tile(CDirectDrawSurface* DSurface, int dt, int x, int y)
//{
//	return TileBank[MapData[dt].TileList.TileBank+(MapData[dt].TileList.Tile*BANKMAX)].Draw(DSurface,x,y);
//}

///////////////////////////////////////////////////////////////////////
// Draw the first layer of Isometric Map. 
// Will draw the tile base for the map.
// This method is for games like:
// Diablo		RPG
// War Games	RT Strategy
HRESULT CC_Map::Draw_Isometric_Tiles(CDirectDrawSurface* DSurface,bool bBuild)
{	
//	HRESULT DDERR;
//	HRESULT DDRETURN;
//	DDRETURN = DD_OK;
	int x,y,dt;	
	int dx,dy;
	int px = X;
	int py = Y;
	int offsetx = 0;

	for(y=0;y<TilesToDrawY+1;y++)
	{
		for(x=0;x<TilesToDrawX+1;x++)
		{
			dt = px + x + ((py - x) * Width);
			if( dt < 0 ) dt=0;
			if( dt > SIZE ) dt=0;

			dx=offsetx+ScrollX+ScreenX+(x*TileWidth);
			dy=ScrollY+ScreenY+(y*(TileHeight/2));

//			DDERR = TileBank[MapData[dt].TileList.TileBank+(MapData[dt].TileList.Tile*BANKMAX)].Draw(DSurface,dx,dy);

//			if(DDERR != DD_OK)
	//			DDRETURN = DDERR;
    */
/*
            if(bBuild)
            {
                if( (MapData[dt].cProperties & GMP_PROPERTY_BLOCKED) == GMP_PROPERTY_BLOCKED)
                    DDERR = BlockedTile->Draw(DSurface,dx,dy);
                else
                    DDERR = PassableTile->Draw(DSurface,dx,dy);

                if(DDERR != DD_OK)
                    DDRETURN = DDERR;
            }
            */
            /*
                         
		}

		if(offsetx)
		{
			py++;
			offsetx = 0;
		}

		else
		{
			px++;
			offsetx = (TileWidth/2);
		}
	}
	return 1;//DDRETURN;
}

///////////////////////////////////////////////////////////////////////
// Draw the second layer of Isometric Map one at a time. 
// This is so that you can put players and monsters in to the drawing loop so
// as not to make them appear on top of everything.
// Will draw objects like walls, torches, houses on map. (stationary items)
void CC_Map::Draw_Isometric_Object(IDirectDrawSurface4* DSurface, int dt, int x, int y, int priority)
{
	if( (pMapData[dt].ObjectList[priority].Object		== GMP_NO_OBJECT) ||
		(pMapData[dt].ObjectList[priority].ObjectBank	== GMP_NO_OBJECT) )
		return;

	int ObjectWidth;
	int DrawAtX;
	int ObjectHeight;
	int DrawAtY;

	if(ObjectBank[pMapData[dt].ObjectList[priority].ObjectBank+(pMapData[dt].ObjectList[priority].Object*BANKMAX)].pSurface->Surface)
	{
		ObjectWidth  = ObjectBank[pMapData[dt].ObjectList[priority].ObjectBank+(pMapData[dt].ObjectList[priority].Object*BANKMAX)].pSurface->Width;
		ObjectHeight = ObjectBank[pMapData[dt].ObjectList[priority].ObjectBank+(pMapData[dt].ObjectList[priority].Object*BANKMAX)].pSurface->Height;
		DrawAtX = ObjectWidth/2 - TileWidth/2; 
		DrawAtY = TileHeight - ObjectHeight;

        RECT rcDRect;
        rcDRect.top    = y+DrawAtY;
        rcDRect.left   = x-DrawAtX;
        rcDRect.bottom = rcDRect.top+ObjectBank[pMapData[dt].ObjectList[priority].ObjectBank+(pMapData[dt].ObjectList[priority].Object*BANKMAX)].pSurface->Height;
        rcDRect.right  = rcDRect.left+ObjectBank[pMapData[dt].ObjectList[priority].ObjectBank+(pMapData[dt].ObjectList[priority].Object*BANKMAX)].pSurface->Width;
        
        DSurface->Blt(&rcDRect,ObjectBank[pMapData[dt].ObjectList[priority].ObjectBank+(pMapData[dt].ObjectList[priority].Object*BANKMAX)].pSurface->Surface,NULL,DDBLT_KEYSRC,NULL);
	}

}

///////////////////////////////////////////////////////////////////////
// Draw the second layer of Isometric Map all at once.
// Will draw objects like walls, torches, houses on map. (stationary items)
void CC_Map::Draw_Isometric_Objects(IDirectDrawSurface4* DSurface)
{
    /*
	int offsetx=0;
	int x,y,dt;
	int px,py;
	char object;
	int ObjectWidth;
	int DrawAtX;
	int ObjectHeight;
	int DrawAtY;
	px = X;
	py = Y;
	for(object=0;object<GMP_OBJECT_LAYERS;object++)
	{
		for(y=0;y<TilesToDrawY+1;y++)
		{
			for(x=0;x<TilesToDrawX+1;x++)
			{
				dt = px + x + ((py - x) * Width);
				if( dt < 0 ) dt=0;
				if( dt > SIZE ) dt=0;
					if( (pMapData[dt].ObjectList[object].Object     == GMP_NO_OBJECT) ||
						(pMapData[dt].ObjectList[object].ObjectBank == GMP_NO_OBJECT))
						continue;

					if(ObjectBank[pOldMapData[dt].ObjectList[object].ObjectBank+(pOldMapData[dt].ObjectList[object].Object*BANKMAX)].pSurface->Surface)
					{
						ObjectWidth  = ObjectBank[pMapData[dt].ObjectList[object].ObjectBank+(pMapData[dt].ObjectList[object].Object*BANKMAX)].pSurface->Width;
						ObjectHeight = ObjectBank[pMapData[dt].ObjectList[object].ObjectBank+(pMapData[dt].ObjectList[object].Object*BANKMAX)].pSurface->Height;
						DrawAtX = ObjectWidth/2 - TileWidth/2 ;
						DrawAtY = TileHeight - ObjectHeight + TileHeight;
						ObjectBank[pMapData[dt].ObjectList[object].ObjectBank+(pMapData[dt].ObjectList[object].Object*BANKMAX)].pSurface->Draw(DSurface,offsetx+ScrollX+ScreenX+(x*TileWidth)-DrawAtX,ScrollY+ScreenY+(y*(TileHeight/2))+DrawAtY);
					}
			}
			if(offsetx == (TileWidth/2))
			{
				py++;
				offsetx = 0;
			}
			else
			{
				px++;
				offsetx = (TileWidth/2);
			}
		}
	}
    *//*
}
*/
// End CC_Map
