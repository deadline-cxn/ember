/***************************************************************
 **      EMBER                                                **
 ***************************************************************/

#ifndef _EMBER_LOG_BASE
#define _EMBER_LOG_BASE

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef _WIN32
#include <direct.h>	// sir004 - 12-22-99 for _getcwd() standard function
#endif

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifndef _WIN32
#include <unistd.h>
#endif

#ifndef _MAX_PATH
#define _MAX_PATH 1024
#endif

class CLog
{
public:
	CLog(void);
    CLog(char *szFilename); // sir003 - 22 Jul 00
	virtual ~CLog(void);

    void Initialize(void);  // sir002 - 22 Jul 00

    void AddEntry(char *fmt, ...);  // sti001
    void AddEntryNoTime(char *fmt, ...);  // sti001

	void AddLineSep(void);
	void SetName(char *szFilename);
	void Off(void);
	void On(void);

    void LineFeedsOn(void); // sir006 - 10 Dec 2000
    void LineFeedsOff(void); // sir007 - 10 Dec 2000

    bool IsActive(void); // sir001 - 22 Jul 00

	bool Restart(void);	// sir005 - 12-22-99 so you can clear the log

	char szBegin[255];
	char szEnd[255];
	char szLineSep[255];
	char logfile[_MAX_PATH];
    char currentdir[_MAX_PATH];
    char logdir[_MAX_PATH];
	bool bActive;
    bool bLineFeeds; // sir008 - 10 Dec 2000
};

#endif // _EMBER_LOG_CLASS
